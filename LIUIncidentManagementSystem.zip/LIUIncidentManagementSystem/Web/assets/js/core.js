/**
 *
 */
let hexToRgba = function(hex, opacity) {
  let result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
  let rgb = result ? {
    r: parseInt(result[1], 16),
    g: parseInt(result[2], 16),
    b: parseInt(result[3], 16)
  } : null;

  return 'rgba(' + rgb.r + ', ' + rgb.g + ', ' + rgb.b + ', ' + opacity + ')';
};
let initCore = function(){
  /** Constant div card */
  const DIV_CARD = 'div.card';

  /** Initialize tooltips */
  $('[data-toggle="tooltip"]').tooltip();

  /** Initialize popovers */
  $('[data-toggle="popover"]').popover({
    html: true
  });

  /** Function for remove card */
  $('[data-toggle="card-remove"]').on('click', function(e) {
    let $card = $(this).closest(DIV_CARD);

    $card.remove();

    e.preventDefault();
    return false;
  });

  /** Function for collapse card */
  $('[data-toggle="card-collapse"]').on('click', function(e) {
    let $card = $(this).closest(DIV_CARD);

    $card.toggleClass('card-collapsed');

    e.preventDefault();
    return false;
  });

  /** Function for fullscreen card */
  $('[data-toggle="card-fullscreen"]').on('click', function(e) {
    let $card = $(this).closest(DIV_CARD);

    $card.toggleClass('card-fullscreen').removeClass('card-collapsed');

    e.preventDefault();
    return false;
  });

  /**  */
  if ($('[data-sparkline]').length) {
    let generateSparkline = function($elem, data, params) {
      $elem.sparkline(data, {
        type: $elem.attr('data-sparkline-type'),
        height: '100%',
        barColor: params.color,
        lineColor: params.color,
        fillColor: 'transparent',
        spotColor: params.color,
        spotRadius: 0,
        lineWidth: 2,
        highlightColor: hexToRgba(params.color, .6),
        highlightLineColor: '#666',
        defaultPixelsPerValue: 5
      });
    };

    require(['sparkline'], function() {
      $('[data-sparkline]').each(function() {
        let $chart = $(this);

        generateSparkline($chart, JSON.parse($chart.attr('data-sparkline')), {
          color: $chart.attr('data-sparkline-color')
        });
      });
    });
  }

  /**  */
  if ($('.chart-circle').length) {
    require(['circle-progress'], function() {
      $('.chart-circle').each(function() {
        let $this = $(this);

        $this.circleProgress({
          fill: {
            color: tabler.colors[$this.attr('data-color')] || tabler.colors.blue
          },
          size: $this.height(),
          startAngle: -Math.PI / 4 * 2,
          emptyFill: '#F4F4F4',
          lineCap: 'round'
        });
      });
    });
  }
};
let chevToggle=function() {
  this.classList.toggle("active");
  const collapsable=this.getElementsByClassName("fe-collapsable").length>0?this.getElementsByClassName("fe-collapsable")[0]:false;
  if (collapsable){
    collapsable.classList.toggle("fe-chevron-up");
    collapsable.classList.toggle("fe-chevron-down");
  }
  var panel = this.nextElementSibling;
  (panel.style.maxHeight) ? panel.style.maxHeight = null : panel.style.maxHeight = panel.scrollHeight + "px";
}
/**
 function for smoothly animated card-accordions
*
 */
let initCC=function(){
  var acc = document.getElementsByClassName("card-accordion");
  for (var i = 0; i < acc.length; i++) {
    acc[i].addEventListener("click",chevToggle);
  }
}
let destroyCC=function(){
  var acc = document.getElementsByClassName("card-accordion");
  for (var i = 0; i < acc.length; i++) {
    acc[i].removeEventListener("click",chevToggle);
  }
}
/**
 *
 * function for switching tabs via next & back buttons
 */
let switchTab=function(direction){
  var startPoint=document.getElementsByClassName("active next-back")[0].getAttribute("data_id")
  if (direction == "next"){
    startPoint++;
    var selector = document.getElementsByClassName("next-back")[startPoint];
    selector.click();
  } 
  else{
    startPoint--;
    var selector = document.getElementsByClassName("next-back")[startPoint]
    selector.click();
  }
}

/** 
 * function for choosing which card to disable text in
 */
let disableText=function(){
  var activeT=document.getElementsByClassName("active");
  var chosenT=activeT[1].href; //all pages have at least 2 active classes. [0] is the outermost navbar. [1] is the active tab which holds the href of the page we are currently in
  var currentT=chosenT.split("#")[1];
  
  let changeButton=function(){
    let x=document.getElementById(currentT);
    var y=x.getElementsByClassName("form-control");
    var z=x.getElementsByClassName("btn")[0];
    for(var i=0;i<y.length;i++)
    {  //disables textbox input
      y[i].disabled===false ? y[i].disabled=true : y[i].disabled=false;
    }
    z.innerHTML=="Edit" ? (z.innerHTML="Lock Changes",z.classList.toggle("btn-success")):(z.classList.toggle("btn-success"),z.innerHTML="Edit"); //changes button content
  }
  return changeButton(currentT);
}
