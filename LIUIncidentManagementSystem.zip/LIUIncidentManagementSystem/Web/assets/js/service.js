class Service {
    constructor(http,subscriber){
        this.debugLogin = false;
        this.debugSearch = true;
        this.debugLoad = true;
        this.isLoggedIn = false;
        this.http = http;
        this.subscriber=subscriber;
    }
    async login(username,password){
        const payload = {
            LDAPUser: username,
            LDAPPass: password,
            module: 'LIUIMS'
        };
        const res = await this.http.post('https://webapps3.liu.edu/BITools/api/v1.0.0/Auth/LDAP',payload);
        if( res.data.Status === 'ok' ){
            let accessData = "token" in res.data.Data ? res.data.Data : this.subscriber.get(["user"]);
            if(accessData.moduleaccess==true || this.debugLogin ){
                this.http.defaults.headers.common["id"]=accessData.uname;
                this.http.defaults.headers.common["token"]=accessData.token;
                this.subscriber.publish(["user"],accessData);
                this.isLoggedIn = true;
            }
            else{
                this.notify({
                    title:"Login Failure",
                    message:"User is not assigned to this application"
                });
            }
        }
        else{
            this.notify({
                title:"Login Failure",
                message:"User has entered incorrect login information or is not assigned to this application"
            });
            this.isLoggedIn = false;
        }
        return res;
    }
    async searchCase(caseID){
        if(this.debugSearch){
            let debugCaseSearch=[
                {   EventID:"00005" },
                {   EventID:"00006" } 
            ].filter((row)=>{return row.EventID.indexOf(caseID)>=0});
            this.subscriber.publish(["search"],{cases:debugCaseSearch});
        }
        else{
            //search in portal
            const searchResponse = await this.http.get("search/?q="+caseID);
            let results = searchResponse.data.result;
            debugger
            if(results.length==0){
                this.loadCase("");
            }
            else{
                this.subscriber.publish(["search"],{
                    cases:results
                });
            }
        }
        
    }
    notify(obj){
        let newNotifications = this.subscriber.get(["notifications"]);
        let notifDate = new Date();
        newNotifications.next+=1;
        let defaultProps = {
            id:newNotifications.next,
            title:"",
            message:"",
            date:notifDate,
            IsActive:true
        };
        let newObj = Object.assign({},defaultProps,obj);
        newNotifications.items.push(newObj);
        this.subscriber.publish(["notifications"],newNotifications)
    }
    async loadCase(caseID){
        if(caseID==""||caseID==null){
            this.subscriber.publish(["navigation"],{
                "top":'home-nav',
                "sub":'home-page'
            });
        }
        else{
            if(this.debugLoad){
                let curCase = {};
                curCase.EventID=caseID;
                curCase.reported="lbanks";
                curCase.Incident=this.debugData.Incident;
                curCase.Person=this.debugData.Person;
                curCase.Medical=this.debugData.Medical;
                curCase.Property=this.debugData.Property;
                curCase.Vehicle=this.debugData.Vehicle;
                curCase.Offense=this.debugData.Offense;
                curCase.Related=this.debugData.Related;
                curCase.Review=this.debugData.Review;
                //Publish case change if match
                this.subscriber.publish(["currentCase"],curCase);
            }
            else{
                const searchResponse = await this.http.get("search/?q="+caseID);
                if(searchResponse.data.result.length==1){
                    const getResponse = await this.http.get("case/"+caseID);
                    let curCase = this.subscriber.get(["currentCase"]);
                    curCase.EventID=caseID;
                    curCase.reported="lbanks";
                    curCase.Incident={};
                    curCase.Person={};
                    curCase.Offense={};
                    curCase.Related={};
                    curCase.Review={};
                    Object.assign(curCase,getResponse.result);
                    //Publish case change if match
                    this.subscriber.publish(["currentCase"],curCase);
                }
                else{
                    this.notify({
                        title:"no search results",
                        message:"Your search for a case like '"+caseID+"' yielded no results"
                    });
                }
                
            }
        }
    }
    navChange(top,sub){
        console.log('top is ', top);
        console.log('sub is ', sub);
        this.subscriber.publish(["navigation"],{
            "top":top,
            "sub":sub
        });
    }
    constrainCase(selected,data){
        let currentCase = this.subscriber.get(["currentCase"]);
        if("constrain" in currentCase){
            currentCase["constrain"][selected] = data;
        }
        else{
            currentCase["constrain"] = { 
                [selected]:data
            };
        }
        this.subscriber.publish(["currentCase"],currentCase);
    }
    async associativeInstance(EventDataSetID){
        EventDataSetID=EventDataSetID+"";
        let index = this.subscriber.get(["index"]);
        let instance = null;
        if( EventDataSetID in index ){
            instance = index[EventDataSetID] 
        } 
        else{
            let query = {
                "filters":[{
                    "id":1,
                    "key":"EventDataSetID",
                    "operator":"=",
                    "value":EventDataSetID
                }],
                "joins":[{
                    "id":1,"parent":-1,"filters":[1,2,3], "operator":"OR"	
                }]
            };
            let response = await this.http.post("/search/",query);
            let category = Object.keys(response.data.result).length > 0 ? Object.keys(response.data.result)[0] : "DNE";
            instance = category=="DNE" ? [] : response.data.result[category].records;
            index[EventDataSetID] = instance;
        }
        this.subscriber.publish(["index"],index);
        return instance;
    }
    debugData = {
        Incident:{
            Records:[{
                "EventDataSetID":1,
                "DispatchDatetime":"2020-01-15T19:29:41",
                "IncidentDatetime":"2020-01-15T19:29:41",
                "InformationReceived":"Phone",
                "Type":"Emergency",
                "Severity":"Medium",
                "Campus":"CW Post",
                "Building":"Mary Lai",
                "Address":"123 Main St",
                "City":"Glen Cove",
                "State":"NY",
                "Postal":"11542",
                "IsMurder":false,
                "IsManslaughter":false,
                "IsRape":false,
                "IsSexualMisconduct":false,
                "IsRobbery":false,
                "IsAggravatedAssault":false,
                "IsBurglary":false, 
                "IsMotorVehicleTheft":false,
                "IsArson":false,
                "IsDomesticViolence":true,
                "IsStalking":false,
                "IsUnfoundedCrimes":false,
                "Description":"Case occurred around 5pm with victim reporting violence by suspect"
            }]
        },
        Person:{
            Records:[{
                "EventDataSetID":1,
                "EMPLID":100554,
                "FirstName":"Ryan",
                "LastName":"Montgomery",
                "MiddleName":null,
                "Phone":"(516) 369-2409",
                "Email":"Ryan.Montgomery@liu.edu",
                "Sex":"M",
                "Race":"W",
                "HairColor":"B",
                "EyeColor":"A",
                "DOB":"02/12/1994",
                "Height":"6\' 2\"",
                "Weight":"120lbs",
                "Campus":"Post",
                "Building":"14",
                "Address": "720 Brookville",
                "address-two": null,
                "City": "NY",
                "Postal":"11026"
                
            }, /*... More data */
            {
                "EventDataSetID":2,
                "EMPLID":100225,
                "FirstName":"Korey",
                "LastName":"Hennegan",
                "MiddleName":"E",
                "Phone":"(999) 999-9999",
                "Email":"Korey.Hennegan@liu.edu",
                "Sex":"M",
                "Race":"B",
                "HairColor":"B",
                "EyeColor":"A",
                "DOB":"03/12/1994",
                "Height":"5 5",
                "Weight":"120lbs",
                "Campus":"BK",
                "Building":"12",
                "Address": "720 Main St",
                "address-two": null,
                "City": "NY",
                "Postal":"11026"

            }, /*... More data */
            {
                "EventDataSetID":3,
                "EMPLID": 100226,
                "FirstName": "Chyna",
                "LastName": "Browne",
                "MiddleName": "R",
                "Phone":"(999) 999-9999",
                "Email":"Chyna.Browne@liu.edu",
                "Sex": "F",
                "Race": "B",
                "HairColor": "B",
                "EyeColor": "A",
                "DOB": "06/12/1994",
                "Height": "5 5",
                "Weight": "120lbs",
                "Campus": "Post",
                "Address": "123 Check St",
                "address-two": null,
                "City": "Brookville",
                "Postal":"11032"

            }, /*... More data */
            {
                "EventDataSetID":4,
                "EMPLID": 100229,
                "FirstName": "Kiichi",
                "LastName": "Takeuchi",
                "MiddleName": "O",
                "Phone":"(999) 999-9999",
                "Email":"Kiichi.Takeuchi@liu.edu",
                "Sex": "M",
                "Race": "A",
                "HairColor": "B",
                "EyeColor": "A",
                "DOB": "02/18/1991",
                "Height": "5 8",
                "Weight": "160lbs",
                "Campus": "BK",
                "Address": null,
                "address-two": null,
                "City": "Brookville",
                "Postal":"11032"
            }]
        },
        Medical:{
            Records:[{
                "EventDataSetID":31,
                "PersonEventDataSetID":1,
                "aid-type":"Medium",
                "date":"2020-01-15T19:29:41",
                "officer-id":"237674900",
                "certified-officer-id":"230091288",
                "TakenBy":"Guardian",
                "TakenTo":"",
                "IsSkinBroken":true,
                "InjuredAppendage":"Leg",
                "Doctor":"Simon",
                "Hospital":"LIJ",
                "Description":"Serious injury of my pride"
            },{
                "EventDataSetID":32,
                "PersonEventDataSetID":2,
                "aid-case":"6573",
                "aid-type":"High",
                "date":"2020-01-15T19:29:41",
                "officer-id":"246578200",
                "certified-officer-id":"230091288",
                "TakenBy":"Policy",
                "TakenTo":"Hospital",
                "IsSkinBroken":true,
                "InjuredAppendage":"Leg",
                "Doctor":"Simon",
                "Hospital":"Queens General",
                "Description":"bruised"
            },{
                "EventDataSetID":33,
                "PersonEventDataSetID":3,
                "aid-case":"2231",
                "aid-type":"High",
                "date":"2020-01-15T19:29:41",
                "officer-id":"23734200",
                "certified-officer-id":"230091288",
                "TakenBy":"Ambulance",
                "TakenTo":"Hospital",
                "IsSkinBroken":true,
                "InjuredAppendage":"Leg",
                "Doctor":"Simon",
                "Hospital":"LIJ",
                "Description":"battered"
            },{
                "EventDataSetID":34,
                "PersonEventDataSetID":4,
                "aid-case":"1234",
                "aid-type":"Medium",
                "date":"2020-01-15T19:29:41",
                "officer-id":"23778200",
                "certified-officer-id":"230091288",
                "TakenBy":"Guardian",
                "TakenTo":"Hospital",
                "IsSkinBroken":true,
                "InjuredAppendage":"Leg",
                "Doctor":"Simon",
                "Hospital":"Queens General",
                "Description":"Indifferent"
            }]
        },
        Property:{
            Records:[{
                "EventDataSetID":11,
                "PersonEventDataSetID":1,
                "ItemName":"My Dignity",
                "Type":"",
                "Value":"Priceless",
                "ItemPhoto":13,
                "IsStolen":false,
                "IsEvidence":true,
                "IsDamaged":true,
                "IsRecovered":true,
                "IsFound":true,
                "IsSafeKeeping":true,
                "Description":"This was my precious property"
            }]
        },
        Vehicle:{
            Records:[]
        },
        Offense:{
            Records:[{
                "EventDataSetID":10,
                "OffenseDatetime":"2020-01-15T19:29:41",
                "Type":"Domestic Violence",
                "VictimDataSetEventID":1,
                "SuspectDataSetEventID":2
            }]
        },
        Related:{
            Records:[{
                "EventDataSetID":1,
                "RelatedEventID":1,
                "Type":"Aided Case"
            }]
        },
        Review:{}
    }
}
export default Service;