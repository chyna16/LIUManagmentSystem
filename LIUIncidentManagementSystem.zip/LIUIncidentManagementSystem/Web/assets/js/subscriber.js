class Subscriber {
    constructor(topics){
        this.topic=topics;
        this.subscriptions={};
        this.subconserver=new function(delay=10){
            this.i=0;
            this.conserve=(logic)=>{
                this.i++;
                setTimeout(()=>{
                    this.i--;
                    this.i==0?logic():0;
                },delay)
            }
        }
    }
    subscribe(path,callback){
        let subpath = path.join("-");
        let uniqId = this.uuidv4();
        var subscription = {
            id:uniqId,
            callback:callback,
            unsubscribe:()=>{
                this.unsubscribe(subpath,uniqId);
            },
            publish:(data)=>{
                this.publish(path,data);
            },
            get:()=>{
                return this.pluck(this.topic,path)
            }
        }
        if(subpath in this.subscriptions){
            this.subscriptions[subpath].push(subscription);
        }
        else{
            this.subscriptions[subpath]=[subscription];
        }
        return subscription;
    }
    unsubscribe(subpath,uniqId){
        let removeAt=-1;
        this.subscriptions[subpath].forEach((subscription,index)=>{
            subscription.id=uniqId ? removeAt=index : removeAt;
        });
        if(this.subscriptions[subpath].length == 1 ){
            removeAt >=0 ? delete this.subscriptions[subpath] : 0 ; 
        }
        else{
            removeAt >=0 ? this.subscriptions[subpath].splice(removeAt,1) : 0 ;
        }  
    }
    get(path){
        return this.pluck(this.topic,path);
    }
    publish(path,data){
        Object.assign(this.pluck(this.topic,path),data);
        this.subconserver.conserve(()=>{
            path.join("-") in this.subscriptions ? this.subscriptions[path.join("-")].forEach((subscription)=>{
                subscription.callback(this.pluck(this.topic,path),subscription);
            }) : 0;
        })
    }
    pluck(data,path,set=null){
        if(path.length>1){
        return this.pluck( data[path[0]] , path.slice(1,path.length) , set );
      }
      else{
          if(path.length==0){
            return data;
          }
          else{
              if(set==null){
                return data[path[0]];
              }
              else{
                data[path[0]]=set;
                return data[path[0]];
              }
          }
      }
    }
    uuidv4() {
        return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
            var r = Math.random() * 16 | 0, v = c == 'x' ? r : (r & 0x3 | 0x8);
            return v.toString(16);
        });
    }
}
export default Subscriber