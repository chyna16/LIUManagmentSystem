import Service from './service.js';
import Subscriber from './subscriber.js';

(async function main() {

  await riot.compile()
  axios.defaults.baseURL="https://localhost:5001";
  const subscriber = new Subscriber({
    "navigation":{
        top: 'home-nav',
        sub: 'home-page'
    },
    "search":{
      "cases":[
        {
          EventID:"00005"
        },
        {
          EventID:"00006"
        } 
      ],
      "people":{},
    },
    "currentCase":{},
    "user":{
      "name":"Jane Doe"
    },
    "index":{
      "Incident":{},
      "Person":{},
      "Medical":{},
      "Property":{},
      "Vehicle":{},
      "Offense":{},
      "Related":{},
      "Review":{},
    },
    "options":{},
    "notifications":{
      next:0,
      items:[]
    }
  });
  const service = new Service(axios,subscriber);
  riot.install((component)=>{
    component.service = service;
    component.subscriber = subscriber;
  });
  console.log('compilation is done!');
  riot.mount('app');
}())