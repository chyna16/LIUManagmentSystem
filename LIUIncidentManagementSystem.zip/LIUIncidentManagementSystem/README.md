LIUIncidentManagementSystem
===============
Update
Incident Management System for Public Safety

## Install

for web, install live-server
```
npm i -g live-server
```

## Starting App

- API - double click sln. Port is 8081
- Web - live-server. Port is 8080

## Deploy

- API - Publish and copy dlls
- Web - Copy tag and js folder. (Preserve config.js inside js folder.)

## Documentation

http://developer.liu.edu:8090/display/WD/LIU+Incident+Management+System