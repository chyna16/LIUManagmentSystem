using System;
using System.Collections.Generic;

namespace LIU.IMS.API.Models{
    public class ResultError {
        public List<FieldError> FieldErrors = new List<FieldError>();
        public List<TransactionError> TransactionErrors = new List<TransactionError>();
    }
}