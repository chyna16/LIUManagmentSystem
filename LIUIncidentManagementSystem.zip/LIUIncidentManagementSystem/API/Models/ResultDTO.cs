using System;

namespace LIU.IMS.API.Models{
    public class ResultDTO {
        public string status {get;set;}
        public string message {get;set;}
        public dynamic result {get;set;}
    }
}