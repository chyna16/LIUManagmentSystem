using System;
using System.Collections.Generic;

namespace LIU.IMS.API.Models{
    public class Event : ResultError {
        public int EventID { get; set;}
        public string Prefix { get; set; }
        public int Type {get;set;}
        public Dictionary<string,Dictionary<string,dynamic>> Categories {get;set;}
        public bool IsActive {get; set; }
    }
}