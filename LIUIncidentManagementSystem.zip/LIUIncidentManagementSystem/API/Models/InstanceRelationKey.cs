using System.Collections.Generic;
public class InstanceRelationKey {
    public int InstanceRelationKeyID {get;set;}
    public int InstanceRelationID {get;set;}
    public string ParentTable {get;set;}
    public string ChildTable {get;set;}
    public string ParentPKCol {get;set;}
    public string ChildPKCol {get;set;}
    public int ParentPKID {get;set;}
    public int ChildPKID {get;set;}
    
}