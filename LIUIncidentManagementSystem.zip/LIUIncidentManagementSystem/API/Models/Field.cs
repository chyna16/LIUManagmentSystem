using System;

namespace LIU.IMS.API.Models{
    public class Field {
        public int FieldID { get; set; }
        public string FieldLabel {get; set;}
        public string FieldDescription {get; set;}
        public string FieldDataType {get;set;}
        public string FieldSelector {get;set;}
        public bool IsActive {get; set;}
        
    }
}