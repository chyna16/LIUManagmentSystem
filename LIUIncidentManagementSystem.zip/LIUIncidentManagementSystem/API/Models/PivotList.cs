using System;
using System.Collections.Generic;
using System.Linq;

namespace LIU.IMS.API.Models{
    public class PivotList : ResultError {
        public List<EventDataSetView> vertical {get; set;}
        public List<Dictionary<string,dynamic>> horizontal {get; set;}
        
        public List<vGroupMapping> vGroups {get;set;}
        public List<Dictionary<string,EventDataSetView>> vHas = new List<Dictionary<string,EventDataSetView>>();

        public PivotList(List<EventDataSetView> vertical){
            this.vertical=vertical;
        }
        public PivotList(List<Dictionary<string,dynamic>> horizontal){
            this.horizontal=horizontal;
        }
        public PivotList(List<dynamic> horizontal){
            this.horizontal=horizontal
                .Select(x => ((IDictionary<string, dynamic>)x)
                .ToDictionary(ks => ks.Key, vs => vs.Value))
                .ToList();
            /*
            for(var i=0; i<this.horizontal.Count;i++){
                this.horizontal[i].EventDataSetID=i
            }
            */
        }

        public PivotList ConstructVertical(Event currentEvent, Category currentCategory){
            this.FieldErrors = new List<FieldError>();
            this.vGroups = new List<vGroupMapping>();
            this.vHas = new List<Dictionary<string,EventDataSetView>>();


            Dictionary<string,CategoryField> fieldDict = new Dictionary<string,CategoryField>();
            currentCategory.FieldCategories.ForEach((CategoryField field)=>{
                fieldDict[field.FieldLabel]=field;
            });

            this.vertical= new List<EventDataSetView>();
            int i=0;
            this.horizontal.ForEach((Dictionary<string,dynamic> set)=>{
                Dictionary<string,EventDataSetView> columns = new Dictionary<string,EventDataSetView>();

                i++;
                vGroups.Add(new vGroupMapping(){
                    vGroupTempSurrogateID=i,
                    vGroupFinalSurrogateID=( set.ContainsKey("EventDataSetID") ? (int) set["EventDataSetID"] : -1 ),
                    vGroupColumns=columns
                });
                foreach(var item in set){
                    if(fieldDict.ContainsKey(item.Key)){

                        EventDataSetView aValue = new EventDataSetView(){
                            EventID=currentEvent.EventID,
                            EventDataSetID=( set.ContainsKey("EventDataSetID") ? (int) set["EventDataSetID"] : -1 ),
                            CategoryID=currentCategory.CategoryID,
                            CategoryLabel=currentCategory.CategoryLabel,
                            FieldID=fieldDict[item.Key].FieldID,
                            FieldLabel=fieldDict[item.Key].FieldLabel,
                            Value=typeConvertIn(item.Value,fieldDict[item.Key].FieldDataType),
                            vGroupTempSurrogateID=i
                        };
                        this.vertical.Add(aValue);
                        columns[item.Key]=aValue;
                    }
                    else{
                        if(item.Key!="EventDataSetID"){
                            this.FieldErrors.Add(new FieldError(){
                                label=item.Key,
                                message="Field '"+item.Key+"' does not exist. Ensure label is defined within FieldCatalog and mapped correctly within CategoryField table",
                                exists=false,
                                valid=false
                            });
                        }
                        else{

                        }
                    }
                }
                set["vGroupTempSurrogateID"]=i;
            });

            this.vGroups.ForEach((vGroupMapping map)=>{
                foreach(var item in fieldDict){
                    if( !(map.vGroupColumns.ContainsKey(item.Key)) ){
                        map.vGroupMissing.Add(new Field(){
                            FieldID=item.Value.FieldID,
                            FieldLabel=item.Key,
                            FieldDescription=item.Value.FieldDescription,
                            FieldDataType=item.Value.FieldDataType,
                            FieldSelector=item.Value.FieldSelector,
                            IsActive=true
                        });
                    }
                }
            });
            return this;
        }
        public PivotList ConstructHorizontal(string[] addColumns = null){
            
            Dictionary<int,Dictionary<string,dynamic>> horizontalSet = new Dictionary<int,Dictionary<string,dynamic>>();
            this.vertical.ForEach((row)=>{
                if(horizontalSet.ContainsKey(row.EventDataSetID)){
                    horizontalSet[row.EventDataSetID][row.FieldLabel]=typeConvertOut(row.Value,row.FieldDataType);
                    
                }
                else{
                    Dictionary<string,dynamic> hRow = new Dictionary<string,dynamic>();
                    hRow["EventDataSetID"]=row.EventDataSetID;
                    hRow[row.FieldLabel]=typeConvertOut(row.Value,row.FieldDataType);
                    horizontalSet[row.EventDataSetID]=hRow;
                    if(addColumns!=null){
                        foreach(string column in addColumns){
                            hRow[column]=typeof(EventDataSetView).GetProperty(column).GetValue(row);
                        }
                    }
                }
                
            });
            List<Dictionary<string,dynamic>> horizontalSetList = new List<Dictionary<string,dynamic>>();
            foreach(var item in horizontalSet){
                horizontalSetList.Add(item.Value);
            }
            this.horizontal=horizontalSetList;
            return this;
        }

        private static string typeConvertIn(dynamic value,string type){
            if(type=="Number"){
                return Convert.ToString(value);
            }
            else{
                return value;
            }
        }
        private static dynamic typeConvertOut(string value,string type){
            if(type=="Number"){
                if(value.IndexOf(".") !=  -1){
                    long intResult;
                    Int64.TryParse(value,out intResult) ;
                    return intResult;
                }
                else{
                    double doubleResult;
                    Double.TryParse(value, out doubleResult);
                    return doubleResult;
                } 
            }
            else{
                return value;
            }
        }
    }
}