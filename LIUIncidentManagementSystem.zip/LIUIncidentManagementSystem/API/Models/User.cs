using System;

namespace LIU.IMS.API.Models{
    public class User : IUser {
        public int UserID {get;set;}
        public string LDAPUser {get;set;}
        public string message {get;set;}
        public string UserMessage { get; set; }
        public dynamic RoleInformation {get;set;}
        public dynamic RoleQueryResults {get;set;}
        public string AppName { get; set; }
    }
}