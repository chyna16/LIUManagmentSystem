using System;
using System.Collections.Generic;

namespace LIU.IMS.API.Models{
    public class vGroupMapping {
        public int vGroupTempSurrogateID {get;set;}
        public int vGroupFinalSurrogateID {get;set;}
        public Dictionary<string,EventDataSetView> vGroupColumns {get;set;}
        public List<Field> vGroupMissing = new List<Field>();
    }
}