using System;
using System.Collections.Generic;

namespace LIU.IMS.API.Models{
    public class Category {
        public int CategoryID { get; set;}
        public string CategoryLabel {get; set; }
        public List<CategoryField> FieldCategories {get; set;}
    }
}