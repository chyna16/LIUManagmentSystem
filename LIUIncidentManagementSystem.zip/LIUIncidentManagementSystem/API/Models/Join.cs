using System.Collections.Generic;

public class Join {
    public int id {get;set;}
    public int parent {get;set;}
    public List<int> filters {get;set;}
    public string @operator {get;set;}
}