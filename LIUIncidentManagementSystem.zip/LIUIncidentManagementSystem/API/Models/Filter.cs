using System.Collections.Generic;
public class Filter {
    public int id {get;set;}
    public string key {get;set;}
    public string @operator {get;set;}
    public dynamic value {get;set;}
    public int EventID {get;set;}
    public int CategoryID {get;set;}
    public List<int> joinpath {get;set;}
    public int joinpathlength {get;set;}
    public string joinpathstr {get;set;}
    public string groupstrprefix {get;set;}
    public string groupstrsuffix {get;set;}
    public Dictionary<string,dynamic> top {get;set;}
}