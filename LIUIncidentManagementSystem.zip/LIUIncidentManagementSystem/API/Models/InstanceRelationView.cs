using System.Collections.Generic;
public class InstanceRelationView {
    public int InstanceRelationID {get;set;}
    public string Type {get;set;}
    public bool IsActive {get;set;}
    public List<InstanceRelationKey> InstanceRelationKeys {get;set;}

}