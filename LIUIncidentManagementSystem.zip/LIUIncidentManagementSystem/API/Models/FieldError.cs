using System;

namespace LIU.IMS.API.Models{
    public class FieldError {
        public string label {get;set;}
        public string message {get;set;}
        public bool exists {get;set;}
        public bool valid {get;set;}
    }
}