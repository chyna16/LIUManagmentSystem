using System;

namespace LIU.IMS.API.Models{
    public class EventDataSetView : Field {
        public int EventDataValueID {get;set;}
        public int vGroupTempSurrogateID {get;set;}
        public int EventDataSetID { get; set;}
        public int EventID {get; set; }
        public int CategoryID { get; set; }
        public string CategoryLabel {get; set;}
        public string Value {get; set;}
    }
}