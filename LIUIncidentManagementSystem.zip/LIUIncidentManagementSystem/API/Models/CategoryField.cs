using System;

namespace LIU.IMS.API.Models{
    public class CategoryField : Field {
        public int CategoryID { get; set;}
        public string CategoryLabel {get; set; }
        public string SelectLabel {get;set;}
        public int IsSearch{get;set;}
    }
}