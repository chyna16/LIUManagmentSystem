using System;

namespace LIU.IMS.API.Models{
    public class TransactionError {
        public string label {get;set;}
        public string message {get;set;}
        public dynamic data {get;set;}
    }
}