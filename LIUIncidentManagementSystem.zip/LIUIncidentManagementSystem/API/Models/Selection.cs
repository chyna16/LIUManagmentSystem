namespace LIU.IMS.API.Models{
    public class Selection {
        public int value {get;set;}
        public string label {get;set;}
    }
}