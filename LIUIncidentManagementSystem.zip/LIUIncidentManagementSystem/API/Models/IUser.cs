using System;

namespace LIU.IMS.API.Models{
    public interface IUser {}
}