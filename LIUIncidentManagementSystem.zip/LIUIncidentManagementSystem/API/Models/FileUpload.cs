namespace LIU.IMS.API.Models{
    public class FileUpload {
        public int EventID {get;set;}
        public int EventDataSetID {get;set;}
        public int FieldID {get;set;}
        public int FileID {get;set;}
        public string Path {get;set;}
        public string Label {get;set;}
        public string Base64 {get;set;}
        public string Extension {get;set;}
    }
}