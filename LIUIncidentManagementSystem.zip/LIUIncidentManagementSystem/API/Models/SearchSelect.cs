using System;
using System.Collections.Generic;

namespace LIU.IMS.API.Models{
    public class SearchSelect {
        public int EventID { get; set;}
        public int CategoryID {get; set;}
        public string CategoryLabel {get; set; }
        public int FieldID {get;set;}
        public string FieldLabel {get;set;}
        public string SearchValue {get;set;}
    }
}