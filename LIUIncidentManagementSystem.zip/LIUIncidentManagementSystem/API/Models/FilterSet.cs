using System.Collections.Generic;
public class FilterSet {
    public List<Filter> filters {get;set;}
    public List<Join> joins {get;set;}
    public int EventID {get; set;}
    public int CategoryID {get;set;}
}