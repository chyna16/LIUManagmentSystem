using System.Linq;
using Microsoft.AspNetCore.Mvc.Filters;
using LIU.IMS.API.Models;
using Newtonsoft.Json;
using Microsoft.AspNetCore.Mvc;
using RestSharp;

// Note: 
// https://stackoverflow.com/questions/31464359/how-do-you-create-a-custom-authorizeattribute-in-asp-net-core
// See the answer by bruno
namespace LIU.IMS.API.API {
    public class AuthorizeAttribute : TypeFilterAttribute {
        public AuthorizeAttribute() : base(typeof(AuthorizeActionFilter)) {}
    }

    public class AuthorizeActionFilter : IAuthorizationFilter {
        public User user;
        public AuthorizeActionFilter(IUser user) { 
            this.user=(User)user;
        }
        public void OnAuthorization(AuthorizationFilterContext context) {
            
            string id = null;
            string token = null;
            // Check if token appears on the header
            var headers = context.HttpContext.Request.Headers.ToDictionary(x => x.Key, x => x.Value);
            if (headers.ContainsKey("token")) {
                token = headers["token"].First();
            }
            if (headers.ContainsKey("id")){
                id = headers["id"].First();
            }

            // If not, check the URI Parameter
            if (string.IsNullOrEmpty(token) || string.IsNullOrEmpty(id)) {
                var queryParameters = context.HttpContext.Request.Query.ToDictionary(x => x.Key, x => x.Value);
                if (queryParameters.ContainsKey("token")) {
                    token = queryParameters["token"];
                }
                if (queryParameters.ContainsKey("id")){
                    id = queryParameters["id"];
                }
            }

            // Bypass if token is DebugToken
            if ( (!string.IsNullOrEmpty(token)) && token == Startup.Settings["DebugToken"] ){
                return;
            }
            //Forbid if token not entered
            if ( string.IsNullOrEmpty(token) || string.IsNullOrEmpty(id) ) {
                context.Result = new ForbidResult();
                return;
            }

            //Start request to BITool profile with token
            var client = new RestClient(Startup.Settings["BITool-Auth"]);
            var request = new RestRequest(Method.POST);
            request.AddHeader("id", id);
            request.AddHeader("token", token);
            request.AddHeader("role", "LIUIMS");
            request.AddHeader("Content-Type", "application/x-www-form-urlencoded");
            IRestResponse response = client.Execute(request);

            dynamic result = JsonConvert.DeserializeObject<dynamic>(response.Content);

            if (result.Message.Value == "Session Active")
            {
                User incoming = result.Data.ToObject<User>();
                this.user.UserID=incoming.UserID;
                this.user.AppName=incoming.AppName;
                this.user.LDAPUser=incoming.LDAPUser;
                this.user.message=incoming.message;
                this.user.RoleInformation=incoming.RoleInformation;
                this.user.RoleQueryResults=incoming.RoleQueryResults;
                this.user.UserMessage=incoming.UserMessage;
            }
            else
            {
                var content = new { status = "error", message = "Session Expired. Please logout and login again" };
                context.Result = new ForbidResult();
            }
            return;
        }
    }
}