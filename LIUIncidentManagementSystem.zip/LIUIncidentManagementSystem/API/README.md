## IMS API
# structure
Normal table structure abstracted for vertical datasets.


# setup
1. Make sure .NET Core SDK 3.X above is installed
2. Open your Visual Studio (not VSCode) then About > Update Latest on 2019


To run this from command line, try those below. I recommend to use VSCode even this is backend project.
If you open it in VSCode, go inside subdirectory API/

```
dotnet -v
dotnet restore
dotnet watch run
```

or hit play button

or use .sln file