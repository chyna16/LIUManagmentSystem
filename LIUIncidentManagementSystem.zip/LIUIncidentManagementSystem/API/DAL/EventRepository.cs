using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using Dapper;
using LIU.IMS.API;
using LIU.IMS.API.Models;
using Newtonsoft.Json;

namespace LIU.IMS.API.DAL{    
    public class EventRepository : BaseRepository {
        public EventRepository(User user) : base(user){}
        
        public List<Event> GetEvents(){
            string sql = @"
                SELECT * FROM [Event] WHERE [IsActive]=(1) 
            ";
            return this.mDb.Query<Event>(sql).ToList();
        }
        
        public Event GetEvent(int eventId){
            string sql=@"
                SELECT * FROM Event WHERE [EventID]=@EventID AND [IsActive]=(1)
            ";
            return this.mDb.Query<Event>(sql,new {
                EventID=eventId
            }).FirstOrDefault();
        }
        public Event GetEventRestore(int eventId){
            Event currentEvent= this.GetEvent(eventId);
            if(currentEvent==null){
                return currentEvent;
            }
            currentEvent.Categories = this.keyBy(this.GetCategories(currentEvent).Select(x=>x.AsDictionary()).ToList(), new string[] {"CategoryLabel"});
            string[] catKeys = currentEvent.Categories.Keys.ToArray();
            Array.ForEach(catKeys,(string category)=>{
                Category currentCategory = currentEvent.Categories[category].ToObject<Category>();
                currentEvent.Categories[category]["Records"]= this.GetEventDataSet(currentEvent,currentCategory).horizontal;
                currentEvent.Categories[category]["Fields"] = this.GetCategoryFields(currentCategory);
            });
            return currentEvent;
        }
        public Event RestoreEvent(Event restoreEvent){
            using(this.mDb){
                this.mDb.Open();
                using(var transaction=this.mDb.BeginTransaction()){
                    try{
                        //SET ALL EventDataValue's INACTIVE
                        this.MarkEventDataValuesInactive(restoreEvent,transaction);
                        //SET ALL EventDataSet'S INACTIVE
                        this.MarkEventDataSetsInactive(restoreEvent,transaction);
                        //SET EVENT INACTIVE
                        this.MarkEventInactive(restoreEvent,transaction);

                        string[] keys = restoreEvent.Categories.Keys.ToArray();
                        List<TransactionError> transactionErrors = new List<TransactionError>();
                        List<FieldError> fieldErrors = new List<FieldError>();
                        foreach(var key in keys){
                            Category currentCategory = this.GetCategory(key,transaction:transaction);
                            int affected = this.UpsertEvent(restoreEvent,transaction:transaction);
                            if(affected != 1){
                                transaction.Rollback();
                                transaction.Dispose();
                                return restoreEvent;
                            }
                            List<Dictionary<string,dynamic>> payload = restoreEvent.Categories[key]["Records"].ToObject<List<Dictionary<string,dynamic>>>();
                            PivotList caseData = this.UpsertEventDataSets(restoreEvent,currentCategory,payload,transaction:transaction);
                            fieldErrors.AddRange(caseData.FieldErrors);
                            transactionErrors.AddRange(caseData.TransactionErrors);
                        }
                        if(transactionErrors.Count>0 || fieldErrors.Count>0){
                            restoreEvent.FieldErrors=fieldErrors;
                            restoreEvent.TransactionErrors=transactionErrors;
                            transaction.Rollback();
                            transaction.Dispose();
                        }
                        else{
                            transaction.Commit();
                            transaction.Dispose();
                        }
                    }
                    catch(Exception e){
                        transaction.Rollback();
                        transaction.Dispose();
                    }
                }
                this.mDb.Close();
            }
            return restoreEvent;
        }

        public Event AddEvent(Event anEvent){
            using(this.mDb){
                this.mDb.Open();
                using(var transaction=this.mDb.BeginTransaction()){
                    try{
                        int affected=this.AddEvent(anEvent,transaction);
                        if(affected!=1){
                            anEvent.TransactionErrors.Add(new TransactionError(){
                                message="Insert on Event Failed",
                                label="Unexpected Result",
                                data=anEvent
                            });
                            transaction.Rollback();
                            transaction.Dispose();
                        }
                        else{
                            transaction.Commit();
                            transaction.Dispose();
                        }
                    }
                    catch(Exception e){
                        transaction.Rollback();
                        transaction.Dispose();
                        throw e;
                    }
                }
                this.mDb.Close();
            }
            return anEvent;
        }
        public Event UpdateEvent(Event anEvent){
            using(this.mDb){
                this.mDb.Open();
                using(var transaction=this.mDb.BeginTransaction()){
                    try{
                        int affected=this.UpsertEvent(anEvent,transaction);
                        if(affected!=1){
                            anEvent.TransactionErrors.Add(new TransactionError(){
                                message="Update on Event Failed",
                                label="Unexpected Result",
                                data=anEvent
                            });
                            transaction.Rollback();
                            transaction.Dispose();
                        }
                        else{
                            transaction.Commit();
                            transaction.Dispose();
                        }
                    }
                    catch(Exception e){
                        transaction.Rollback();
                        transaction.Dispose();
                        throw e;
                    }
                }
                this.mDb.Close();
            }
            return anEvent;
        }
        public Event DeleteEvent(Event anEvent){
            using(this.mDb){
                this.mDb.Open();
                using(var transaction=this.mDb.BeginTransaction()){
                    try {
                        int affected=this.DeleteEvent(anEvent,transaction);
                        if(affected!=1){
                            anEvent.TransactionErrors.Add(new TransactionError(){
                                message="Delete on Event Failed",
                                label="Unexpected Result",
                                data=anEvent
                            });
                            transaction.Rollback();
                            transaction.Dispose();
                        }
                        else{
                            transaction.Commit();
                            transaction.Dispose();
                        }
                    }
                    catch(Exception e){
                        transaction.Rollback();
                        transaction.Dispose();
                        throw e;
                    }
                }
                this.mDb.Close();
            }
            return anEvent;
        }
        
        public PivotList UpsertEventDataSets(Event currentEvent,Category currentCategory,List<Dictionary<string,dynamic>> payload,IDbTransaction transaction){
            currentCategory.FieldCategories = this.GetCategoryFields(currentCategory,transaction:transaction);    
            PivotList caseData = new PivotList(payload).ConstructVertical(currentEvent,currentCategory);
            if(caseData.FieldErrors.Count>0){
                return caseData;
            }
            try{
                caseData.TransactionErrors= new List<TransactionError>();
                caseData.vGroups.ForEach((map)=>{
                    int numcomplete = this.UpsertEventDataSet(map.vGroupFinalSurrogateID,currentEvent.IsActive,transaction);
                    if(numcomplete==0){
                        caseData.TransactionErrors.Add(new TransactionError(){
                            message="Upsert on EventDataSet Failed",
                            label="Unexpected Result",
                            data=new{EventDataSetID=map.vGroupFinalSurrogateID}
                        });
                    }
                    List<EventDataSetView> groupUpdate = caseData.vertical.Where(aColumnValue=>aColumnValue.EventDataSetID==map.vGroupFinalSurrogateID).ToList();
                    groupUpdate.ForEach((aColumnValue)=>{
                        aColumnValue.IsActive=currentEvent.IsActive;
                        int UpdatedRows = this.UpsertEventDataValue(aColumnValue,transaction);
                        if(UpdatedRows!=1){
                            caseData.TransactionErrors.Add(new TransactionError(){
                                message="Upsert On Data Failed",
                                label="Unexpected Result",
                                data=aColumnValue
                            });
                        }
                    });
                });
                
            }
            catch(Exception e){
                transaction.Rollback();
                transaction.Dispose();
                throw e;
            }
            return caseData;
        }
    }
}