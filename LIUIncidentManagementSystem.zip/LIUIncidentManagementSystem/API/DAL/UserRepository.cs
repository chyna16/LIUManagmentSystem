using System;
using System.Linq;
using System.Collections;
using System.Collections.Generic;
using LIU.IMS.API.Models;
using Dapper;

namespace LIU.IMS.API.DAL{    
    public class UserRepository : BaseRepository {
        public UserRepository(User user) : base(user){}
        public List<User> GetAllUsers() {
            return this.mDb.Query<User>(@"SELECT * FROM [Users]").ToList();
        }


    }
}