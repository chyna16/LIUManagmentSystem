using System;
using System.Linq;
using System.Collections;
using System.Collections.Generic;
using LIU.IMS.API.Models;
using Dapper;
using System.IO;
using MimeTypes;

namespace LIU.IMS.API.DAL{    
    public class FileRepository : BaseRepository {
        public FileRepository(User user) : base(user){}
        
        public FileUpload GetFile(FileUpload requestedFile){
            return this.LoadFileBase64(requestedFile);
        }
        public FileStream GetFileStream(FileUpload requestedFile){
            return this.LoadFileStream(requestedFile);
            
        }
        public FileUpload AddFile(FileUpload currentFile){
            if(currentFile.EventID>0 && currentFile.EventDataSetID>0 && currentFile.FieldID>0){
                currentFile.Path="Event/"+currentFile.EventID+"/EventDataSet/"+currentFile.EventDataSetID+"/Field/"+currentFile.FieldID;
            }
            else if(currentFile.EventID>0 && currentFile.EventDataSetID>0){
                currentFile.Path="Event/"+currentFile.EventID+"/EventDataSet/"+currentFile.EventDataSetID;
            }
            else if(currentFile.EventID>0){
                currentFile.Path="Event/"+currentFile.EventID;
            }
            else{
                currentFile.Path="Common/";
            }
            int surrogate = this.StoreFile(currentFile);
            currentFile.FileID=surrogate;
            currentFile.Base64=null;
            return currentFile;
        }
    
        public string GetFileType(string fileName)
        {
            int extensionStart = fileName.LastIndexOf(".");
            if (extensionStart == -1)
            {
                return "application/octet-stream";
            }
            string ext = fileName.Substring(extensionStart, fileName.Length - extensionStart);
            return MimeTypeMap.GetMimeType(ext);
        }
    }
}