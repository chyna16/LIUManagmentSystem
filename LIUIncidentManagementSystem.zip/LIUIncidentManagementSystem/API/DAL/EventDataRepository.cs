using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using Dapper;
using LIU.IMS.API;
using LIU.IMS.API.Models;

namespace LIU.IMS.API.DAL{    
    public class EventDataRepository : BaseRepository {
        public EventDataRepository(User user) : base(user){}
        
        public PivotList AddEventDataSets(Event currentEvent,Category currentCategory,List<Dictionary<string,dynamic>> payload){ 
            currentCategory.FieldCategories = this.GetCategoryFields(currentCategory,transaction:null);    
            PivotList caseData = new PivotList(payload).ConstructVertical(currentEvent,currentCategory);
            if(caseData.FieldErrors.Count>0){
                return caseData;
            }
            using(this.mDb){
                this.mDb.Open();
                using(var transaction=this.mDb.BeginTransaction()){
                    try{
                        caseData.vGroups.ForEach((vGroupMapping map)=>{
                            map.vGroupFinalSurrogateID = this.AddEventDataSet(currentEvent,currentCategory,transaction);
                            
                            List<EventDataSetView> insertBatch = caseData.vertical.Where((EventDataSetView aColumnValue) => { 
                                return aColumnValue.vGroupTempSurrogateID==map.vGroupTempSurrogateID; 
                            }).ToList();

                            insertBatch.ForEach((EventDataSetView aColumnValue)=>{
                                aColumnValue.EventDataSetID=map.vGroupFinalSurrogateID;
                                this.AddEventDataValue(aColumnValue,transaction);
                            });
                        });
                        transaction.Commit();
                        transaction.Dispose();
                    }
                    catch(Exception e){
                        transaction.Rollback();
                        transaction.Dispose();
                        throw e;
                    }
                }
            }
            caseData.vGroups.ForEach((map)=>{
                var row = caseData.horizontal.Where((item)=>item["vGroupTempSurrogateID"]==map.vGroupTempSurrogateID).First();
                row["EventDataSetID"]=map.vGroupFinalSurrogateID;
                row.Remove("vGroupTempSurrogateID");
            });
            return caseData;
        }

        public PivotList UpdateEventDataSets(Event currentEvent,Category currentCategory,List<Dictionary<string,dynamic>> payload){
            currentCategory.FieldCategories = this.GetCategoryFields(currentCategory,transaction:null);    
            PivotList caseData = new PivotList(payload).ConstructVertical(currentEvent,currentCategory);
            if(caseData.FieldErrors.Count>0){
                return caseData;
            }
            using(this.mDb){
                this.mDb.Open();
                using(var transaction=this.mDb.BeginTransaction()){
                    try{
                        caseData.vGroups.ForEach((vGroupMapping map)=>{
                            this.UpsertEventDataSet(map.vGroupFinalSurrogateID,true,transaction);
                            
                            List<EventDataSetView> insertBatch = caseData.vertical.Where((EventDataSetView aColumnValue) => { 
                                return aColumnValue.vGroupTempSurrogateID==map.vGroupTempSurrogateID; 
                            }).ToList();

                            insertBatch.ForEach((EventDataSetView aColumnValue)=>{
                                aColumnValue.EventDataSetID=map.vGroupFinalSurrogateID;
                                aColumnValue.IsActive=true;
                                this.UpsertEventDataValue(aColumnValue,transaction);
                            });
                        });
                        transaction.Commit();
                        transaction.Dispose();
                    }
                    catch(Exception e){
                        transaction.Rollback();
                        transaction.Dispose();
                        throw e;
                    }
                }
            }
            caseData.vGroups.ForEach((map)=>{
                var row = caseData.horizontal.Where((item)=>item["vGroupTempSurrogateID"]==map.vGroupTempSurrogateID).First();
                row.Remove("vGroupTempSurrogateID");
            });
            return caseData;
        }
    
        public PivotList DeleteEventDataSets(Event currentEvent,Category currentCategory,List<Dictionary<string,dynamic>> payload){
            currentCategory.FieldCategories = this.GetCategoryFields(currentCategory,transaction:null);    
            PivotList caseData = new PivotList(payload).ConstructVertical(currentEvent,currentCategory);
            if(caseData.FieldErrors.Count>0){
                return caseData;
            }
            using(this.mDb){
                this.mDb.Open();
                using(var transaction=this.mDb.BeginTransaction()){
                    try{
                        caseData.vGroups.ForEach((vGroupMapping map)=>{
                            this.DeleteEventDataSet(map.vGroupFinalSurrogateID,transaction);
                            List<EventDataSetView> insertBatch = caseData.vertical.Where((EventDataSetView aColumnValue) => { 
                                return aColumnValue.vGroupTempSurrogateID==map.vGroupTempSurrogateID; 
                            }).ToList();

                            insertBatch.ForEach((EventDataSetView aColumnValue)=>{
                                aColumnValue.EventDataSetID=map.vGroupFinalSurrogateID;
                                this.DeleteEventDataValue(aColumnValue,transaction);
                            });
                        });
                        transaction.Commit();
                        transaction.Dispose();
                    }
                    catch(Exception e){
                        transaction.Rollback();
                        transaction.Dispose();
                        throw e;
                    }
                }
            }
            caseData.vGroups.ForEach((map)=>{
                var row = caseData.horizontal.Where((item)=>item["vGroupTempSurrogateID"]==map.vGroupTempSurrogateID).First();
                row.Remove("vGroupTempSurrogateID");
            });
            return caseData;
        }
    
        public PivotList GetEventDataSets(Event currentEvent,Category currentCategory){
            return this.GetEventDataSet(currentEvent,currentCategory).ConstructHorizontal(); 
        }
    
        public PivotList CopyEventDataSet(Event currentEvent,int EventDataSetID){
            PivotList caseData = GetEventDataSetByID(EventDataSetID,null);
            if(caseData.vertical.Count>0){
                Category currentCategory = GetCategory(caseData.vertical[0].CategoryLabel);
                currentCategory.FieldCategories = this.GetCategoryFields(currentCategory,transaction:null);
                if(caseData.FieldErrors.Count>0){
                    return caseData;
                }
                caseData.ConstructVertical(currentEvent,currentCategory);
                using(this.mDb){
                    this.mDb.Open();
                    using(var transaction=this.mDb.BeginTransaction()){
                        try{
                            caseData.vGroups.ForEach((vGroupMapping map)=>{
                                map.vGroupFinalSurrogateID = this.AddEventDataSet(currentEvent,currentCategory,transaction);
                                
                                InstanceRelationView recordLink = new InstanceRelationView(){
                                    Type="Copy",
                                    IsActive=true
                                };
                                int InstanceRelationID = this.AddInstanceRelation(recordLink,transaction);
                            
                                recordLink.InstanceRelationID=InstanceRelationID;
                                InstanceRelationKey recordLinkDetails = new InstanceRelationKey(){
                                    InstanceRelationID=InstanceRelationID,
                                    ParentTable="EventDataSet",
                                    ChildTable="EventDataSet",
                                    ParentPKCol="EventDataSetID",
                                    ChildPKCol="EventDataSetID",
                                    ParentPKID=EventDataSetID,
                                    ChildPKID=map.vGroupFinalSurrogateID
                                };
                                int InstanceRelationKeyID = this.AddInstanceRelationKey(recordLinkDetails,transaction);
                                List<EventDataSetView> insertBatch = caseData.vertical.Where((EventDataSetView aColumnValue) => { 
                                    return aColumnValue.vGroupTempSurrogateID==map.vGroupTempSurrogateID; 
                                }).ToList();

                                insertBatch.ForEach((EventDataSetView aColumnValue)=>{
                                    aColumnValue.EventDataSetID=map.vGroupFinalSurrogateID;
                                    this.AddEventDataValue(aColumnValue,transaction);
                                });
                                List<EventDataSetView> oldSet = caseData.vertical;
                                List<EventDataSetView> newSet = this.GetEventDataSetByID(map.vGroupFinalSurrogateID,transaction).vertical;

                                this.Audit("EventDataSet","COPY",-1,oldSet,newSet,transaction);
                            });
                            transaction.Commit();
                            transaction.Dispose();
                        }
                        catch(Exception e){
                            transaction.Rollback();
                            transaction.Dispose();
                            throw e;
                        }
                    }
                }
                caseData.vGroups.ForEach((map)=>{
                    var row = caseData.horizontal.Where((item)=>item["vGroupTempSurrogateID"]==map.vGroupTempSurrogateID).First();
                    row["EventDataSetID"]=map.vGroupFinalSurrogateID;
                    row.Remove("vGroupTempSurrogateID");
                });
                return caseData;
            }
            else{
                return caseData;
            }
        }
    
        public PivotList GetPastLinkedEventDataSet(int EventDataSetID){
            string sql = @"
                WITH BackwardEventDataSetHistory(LastParentPKID,LastChildPKID) AS (
                    SELECT ParentPKID,ChildPKID
                    FROM [InstanceRelationKey]
                    WHERE [ChildPKID] = @EventDataSetID
                    UNION ALL
                    SELECT ParentPKID,ChildPKID
                    FROM [InstanceRelationKey] irk
                        JOIN BackwardEventDataSetHistory bedsh on irk.[ChildPKID]=bedsh.[LastParentPKID]
                )
                SELECT 
                eds.[EventDataSetID],
                eds.[EventID],
                eds.[CategoryID],
                cat.[Label] CategoryLabel,
                fc.[FieldID],
                fc.[Label] FieldLabel,
                edv.[Value]
                FROM [EventDataSet] eds
                    JOIN [EventDataValue] edv ON eds.[EventDataSetID]=edv.[EventDataSetID]
                        JOIN [FieldCatalog] fc ON edv.[FieldID]=fc.[FieldID]
                            JOIN [Category] cat ON eds.[CategoryID]=cat.[CategoryID]
                WHERE eds.[EventDataSetID] IN (
                    SELECT LastParentPKID EventDataSetID FROM BackwardEventDataSetHistory UNION
                    SELECT @EventDataSetID EventDataSetID
                )
            ";
            List<EventDataSetView> vResults = this.mDb.Query<EventDataSetView>(sql,new {EventDataSetID=EventDataSetID}).ToList();
            PivotList EventDataPivot = new PivotList(vResults);
            return EventDataPivot.ConstructHorizontal(new string[]{"EventID","CategoryLabel"});
        }

        public PivotList GetFutureLinkedEventDataSet(int EventDataSetID){
            string sql = @"
                WITH ForwardEventDataSetHistory(LastParentPKID,LastChildPKID) AS (
                    SELECT ParentPKID,ChildPKID
                    FROM [InstanceRelationKey]
                    WHERE [ParentPKID] = @EventDataSetID
                    UNION ALL
                    SELECT ParentPKID,ChildPKID
                    FROM [InstanceRelationKey] irk
                        JOIN ForwardEventDataSetHistory fedsh on irk.[ParentPKID]=fedsh.[LastChildPKID]
                )
                SELECT 
                eds.[EventDataSetID],
                eds.[EventID],
                eds.[CategoryID],
                cat.[Label] CategoryLabel,
                fc.[FieldID],
                fc.[Label] FieldLabel,
                edv.[Value]
                FROM [EventDataSet] eds
                    JOIN [EventDataValue] edv ON eds.[EventDataSetID]=edv.[EventDataSetID]
                        JOIN [FieldCatalog] fc ON edv.[FieldID]=fc.[FieldID]
                            JOIN [Category] cat ON eds.[CategoryID]=cat.[CategoryID]
                WHERE eds.[EventDataSetID] IN (
                    SELECT LastChildPKID EventDataSetID FROM ForwardEventDataSetHistory UNION
                    SELECT @EventDataSetID EventDataSetID
                )
            ";
            List<EventDataSetView> vResults = this.mDb.Query<EventDataSetView>(sql,new {EventDataSetID=EventDataSetID}).ToList();
            PivotList EventDataPivot = new PivotList(vResults);
            return EventDataPivot.ConstructHorizontal(new string[]{"EventID","CategoryLabel"});
        }

        public PivotList GetAllLinkedEventDataSet(int EventDataSetID){
            string sql = @"
                WITH ForwardEventDataSetHistory(LastParentPKID,LastChildPKID) AS (
                    SELECT ParentPKID,ChildPKID
                    FROM [InstanceRelationKey]
                    WHERE [ParentPKID] = @EventDataSetID
                    UNION ALL
                    SELECT ParentPKID,ChildPKID
                    FROM [InstanceRelationKey] irk
                        JOIN ForwardEventDataSetHistory fedsh on irk.[ParentPKID]=fedsh.[LastChildPKID]
                ),
                BackwardEventDataSetHistory(LastParentPKID,LastChildPKID) AS (
                    SELECT ParentPKID,ChildPKID
                    FROM [InstanceRelationKey]
                    WHERE [ChildPKID] = @EventDataSetID
                    UNION ALL
                    SELECT ParentPKID,ChildPKID
                    FROM [InstanceRelationKey] irk
                        JOIN BackwardEventDataSetHistory bedsh on irk.[ChildPKID]=bedsh.[LastParentPKID]
                )
                SELECT 
                eds.[EventDataSetID],
                eds.[EventID],
                eds.[CategoryID],
                cat.[Label] CategoryLabel,
                fc.[FieldID],
                fc.[Label] FieldLabel,
                edv.[Value]
                FROM [EventDataSet] eds
                    JOIN [EventDataValue] edv ON eds.[EventDataSetID]=edv.[EventDataSetID]
                        JOIN [FieldCatalog] fc ON edv.[FieldID]=fc.[FieldID]
                            JOIN [Category] cat ON eds.[CategoryID]=cat.[CategoryID]
                WHERE eds.[EventDataSetID] IN (
                    SELECT LastChildPKID EventDataSetID FROM ForwardEventDataSetHistory UNION
                    SELECT LastParentPKID EventDataSetID FROM BackwardEventDataSetHistory UNION
                    SELECT @EventDataSetID EventDataSetID
                )
            ";
            List<EventDataSetView> vResults = this.mDb.Query<EventDataSetView>(sql,new {EventDataSetID=EventDataSetID}).ToList();
            PivotList EventDataPivot = new PivotList(vResults);
            return EventDataPivot.ConstructHorizontal(new string[]{"EventID","CategoryLabel"});
        }
    }
}