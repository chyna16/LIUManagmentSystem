using System;
using System.Text;
using System.IO;
using System.Reflection;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using Dapper;
using LIU.IMS.API;
using LIU.IMS.API.Models;
using Newtonsoft.Json;

namespace LIU.IMS.API.DAL{    
    public class BaseRepository {
        protected readonly IDbConnection mDb;
        protected readonly User user;
        public BaseRepository(User user) {
            this.mDb = new SqlConnection(Startup.ConnectionString); // TODO Wrap all CRUD with proper using statement
            this.user=user;
        }

        public List<Category> GetCategories(){
            string sql = @"SELECT CategoryID,Label CategoryLabel FROM [Category] WHERE IsActive=(1)";
            return this.mDb.Query<Category>(sql).ToList();
        }
        public List<Category> GetCategories(Event anEvent){
            string sql = @"
                SELECT cat.[CategoryID],cat.[Label] CategoryLabel 
                FROM [Category] cat
                    JOIN [EventDataSet] eds ON cat.[CategoryID] = eds.[CategoryID]
                WHERE eds.EventID=@EventID
            "; 
            return this.mDb.Query<Category>(sql,new {EventID=anEvent.EventID}).ToList();
        }  
        public Category GetCategory(string categoryLabel,IDbTransaction transaction=null){
            string sql = @"SELECT CategoryID,Label CategoryLabel FROM Category WHERE [Label]=@CategoryLabel";
            List<Category> Categories=this.mDb.Query<Category>(sql,new {CategoryLabel=categoryLabel},transaction:transaction).ToList();
            return Categories.FirstOrDefault();
        }
        public List<CategoryField> GetCategoryFields(Category aCategory,IDbTransaction transaction=null){
            string sql = @"
                SELECT
                cat.[CategoryID],
                cat.[Label] CategoryLabel,
                fc.[FieldID],
                fc.[Label] FieldLabel,
                fc.[Description] FieldDescription,
                fc.[Selector] FieldSelector,
                fc.[DataType] FieldDataType
                FROM [FieldCatalog] fc
                    JOIN [CategoryField] fcat ON fc.[FieldID]=fcat.[FieldID]
                        JOIN [Category] cat ON fcat.[CategoryID]=cat.[CategoryID]
                WHERE cat.[CategoryID]=@CategoryID AND fc.[IsActive]=(1) AND fcat.[IsActive]=(1)
            ";
            return this.mDb.Query<CategoryField>(sql,new {CategoryID=aCategory.CategoryID},transaction:transaction).ToList();
        }       
        public List<CategoryField> GetSearchSelectCategoryFields(Category searchCategory,Field searchField){
            string sql = @"
                SELECT DISTINCT
                fc.FieldID,
                fc.Label FieldLabel,
                fc.Description FieldDescription,
                fc.Selector FieldSelector,
                fc.DataType FieldDataType,
                cf.CategoryID,
                c.Label CategoryLabel,
                CASE 
                    WHEN rs.SelectLabel IS NULL THEN 
                        c.SelectLabel
                    ELSE
                        rs.SelectLabel
                END SelectLabel,
                1 IsActive
                FROM [CategoryField] cf
                    JOIN [FieldCatalog] fc ON cf.FieldID=f.FieldID
                        JOIN [Category] c ON cf.CategoryID=c.CategoryID
                            JOIN [RelationalSearch] rs ON cf.CategoryID=rs.SelectCategoryID
                WHERE f.IsActive=1 AND cf.IsActive=1 AND c.Category.IsActive=1 AND cf.IsSearch=1 AND
                rs.SearchCategoryID=@SearchCategoryID AND rs.SearchFieldID=@SearchFieldID
            ";
            return this.mDb.Query<CategoryField>(sql,new{SearchCategoryID=searchCategory.CategoryID,SearchFieldID=searchField.FieldID}).ToList();
        }

        public Field GetField(string fieldLabel){
            string sql = @"SELECT * FROM [FieldCatalog] WHERE [Label]=@fieldLabel AND IsActive=1";
            return this.mDb.Query<Field>(sql,new{fieldLabel=fieldLabel}).SingleOrDefault();
        }
        public List<Field> GetFields(){
            string sql = @"
                SELECT
                fc.[FieldID],
                fc.[Label] FieldLabel,
                fc.[Description] FieldDescription,
                fc.[Selector] FieldSelector,
                fc.[DataType] FieldDataType
                FROM [FieldCatalog] fc
                    JOIN [CategoryField] fcat ON fc.[FieldID]=fcat.[FieldID]
                WHERE fc.[IsActive]=(1)
            ";
            return this.mDb.Query<Field>(sql).ToList();
        }
        
        
        public Dictionary<string,Dictionary<string,dynamic>> keyBy(List<Dictionary<string,dynamic>> input, string[] superkey){
            Dictionary<string,Dictionary<string,dynamic>> dict = new Dictionary<string,Dictionary<string,dynamic>>();
            input.ForEach((row)=>{
                string valuekey= string.Join("-",superkey.Select(key=>row[key]));
                dict[valuekey]=row;
            });
            return dict;
        }
        public Dictionary<string,dynamic> keyBySimple(List<Dictionary<string,dynamic>> input, string[] superkey){
            Dictionary<string,dynamic> dict = new Dictionary<string,dynamic>();
            input.ForEach((row)=>{
                string valuekey= string.Join("-",superkey.Select(key=>row[key]));
                dict[valuekey]=row;
            });
            return dict;
        }

        public List<Event> SearchEvent(int EventID){
            string sql = @"
                SELECT * 
                FROM [Event] 
                WHERE CAST([EventID] as varchar) LIKE '%'+CAST(@EventID as varchar)+'%'
                AND [IsActive]=(1)
            ";
            List<Event> matchedEvents = this.mDb.Query<Event>(sql,new{EventID=EventID}).ToList();
            matchedEvents.ForEach(Event=>{
                Event.Categories=this.keyBy(this.GetCategories(Event).Select(x=>x.AsDictionary()).ToList(),new string[]{"CategoryLabel"});
            });
            return matchedEvents;
        }

        public Dictionary<string,Dictionary<string,dynamic>> SearchEventDataSet(string term,string domain=null){
            string sql = @"
                SELECT
                eds.[EventDataSetID],
                eds.[EventID],
                eds.[CategoryID],
                cat.[Label] CategoryLabel,
                fc.[FieldID],
                fc.[Label] FieldLabel,
                edv.[Value]
                FROM [EventDataSet] eds
                    JOIN [EventDataValue] edv ON eds.[EventDataSetID]=edv.[EventDataSetID]
                        JOIN [FieldCatalog] fc ON edv.[FieldID]=fc.[FieldID]
                            JOIN [Category] cat ON eds.[CategoryID]=cat.[CategoryID]
                WHERE eds.[EventDataSetID] IN (
                    SELECT [EventDataSetID] 
                    FROM [EventDataValue]
                    WHERE [FieldID]=1 AND [Value] LIKE '%'+@term+'%'
                    UNION
                    SELECT [EventDataSetID] 
                    FROM [EventDataValue]
                    WHERE [FieldID]=2 AND [Value] LIKE '%'+@term+'%'
                ) AND
                eds.[IsActive]=(1) " + (domain!=null ? " AND cat.[Label]=@domain " : "");
            return categorizeValues(this.mDb.Query<EventDataSetView>(sql,new{term=term,domain=domain}).ToList());
        }

        public Dictionary<string,Dictionary<string,dynamic>> SearchEventDataSetDynamic(string key,string value){
            return new Dictionary<string,Dictionary<string,dynamic>>();
        }

        public Dictionary<string,Dictionary<string,dynamic>> SearchEventDataSetAdvanced(FilterSet filterSet){
            List<Field> searchCriteriaMissing= new List<Field>();
            List<Filter> valueNotSupported = new List<Filter>();
            Dictionary<string,dynamic> fieldCatalog = this.keyBySimple(this.GetFields().Select(x=>x.AsDictionary()).ToList(),new string[]{"FieldLabel"});
            Dictionary<string,dynamic> flatParams = new Dictionary<string,dynamic>();
            filterSet.filters.ForEach((filter)=>{
                if( !(fieldCatalog.ContainsKey(filter.key)) ){
                    if(filter.key != "EventDataSetID"){
                        searchCriteriaMissing.Add(new Field(){
                            FieldLabel=filter.key
                        });
                    }
                }
                else{
                    flatParams["FieldID"+filter.id]=fieldCatalog[filter.key]["FieldID"];
                }
                if(filter.value.GetType().FullName=="System.String" || filter.value.GetType().FullName=="System.Integer" || filter.value.GetType().FullName=="System.Int64"){
                    if(filter.@operator=="in" || filter.@operator=="not in"){
                        flatParams["Value"+filter.id]=new List<dynamic>(){filter.value};
                    }
                    else{
                        flatParams["Value"+filter.id]=filter.value;
                    }
                }
                else if(filter.value.GetType().FullName=="Newtonsoft.Json.Linq.JArray" && (filter.@operator=="in" || filter.@operator=="not in") ){
                    flatParams["Value"+filter.id]=filter.value.ToObject<List<dynamic>>();
                }
                else{
                    valueNotSupported.Add(new Filter(){
                        key=filter.key,
                        @operator=filter.@operator, 
                        value=filter.value
                    });
                }
            });
            if(searchCriteriaMissing.Count>0||valueNotSupported.Count>0){
                Dictionary<string,Dictionary<string,dynamic>>  issues = new Dictionary<string,Dictionary<string,dynamic>>();
                Dictionary<string,dynamic> missingFieldsDict =  this.keyBySimple(searchCriteriaMissing.Select(x=>x.AsDictionary()).ToList(), new string[]{"FieldLabel"});
                Dictionary<string,dynamic> unsupported = this.keyBySimple(valueNotSupported.Select(x=>x.AsDictionary()).ToList(), new string[] {"key"});
                searchCriteriaMissing.ForEach(x=>{
                    missingFieldsDict[x.FieldLabel]=false;
                });
                issues["missing"]=missingFieldsDict;
                issues["unsupported"]=unsupported;
                return issues;
            }

            string relationalstr = "";
            if(filterSet.EventID>0 || filterSet.CategoryID>0){
                List<string> relationalsuffix = new List<string>();
                if(filterSet.EventID>0){
                    relationalsuffix.Add("eds.EventID="+filterSet.EventID);
                }
                if(filterSet.CategoryID>0){
                    relationalsuffix.Add("eds.CategoryID="+filterSet.CategoryID);
                }
                relationalstr=" AND "+string.Join(" AND ",relationalsuffix);
            }   

            string sql = @"
                SELECT
                eds.[EventDataSetID],
                eds.[EventID],
                eds.[CategoryID],
                cat.[Label] CategoryLabel,
                fc.[FieldID],
                fc.[Label] FieldLabel,
                edv.[Value]
                FROM [EventDataSet] eds
                    JOIN [EventDataValue] edv ON eds.[EventDataSetID]=edv.[EventDataSetID]
                        JOIN [FieldCatalog] fc ON edv.[FieldID]=fc.[FieldID]
                            JOIN [Category] cat ON eds.[CategoryID]=cat.[CategoryID]
                WHERE eds.[EventDataSetID] IN ( 
                    " + getNestedConditionalQueries(filterSet) + @" ) "+relationalstr+@"
            ";
            return categorizeValues(this.mDb.Query<EventDataSetView>(sql,new DynamicParameters(flatParams)).ToList());
        }

        public Dictionary<string,Dictionary<string,dynamic>> categorizeValues(List<EventDataSetView> uncategorized){
            List<Dictionary<string,dynamic>> unkeyedCategories = uncategorized.Select(x=>{
                Dictionary<string,dynamic> dict = new Dictionary<string,dynamic>();
                dict["CategoryID"]=x.CategoryID;
                dict["CategoryLabel"]=x.CategoryLabel;
                return dict;
            }).ToList();

            Dictionary<string,Dictionary<string,dynamic>> categories = this.keyBy(unkeyedCategories,new string[]{ "CategoryLabel" });
            string[] catKeys = categories.Keys.ToArray();
            foreach(string key in catKeys){
                PivotList catSearch=new PivotList(uncategorized.Where(x=>x.CategoryLabel==key).ToList());
                catSearch.ConstructHorizontal();
                categories[key]["records"]=catSearch.horizontal;
            }
            return categories;
        }

        
        public string getNestedConditionalQueries(FilterSet filterSet){
            List<Filter> unsorted = filterSet.filters;
            List<Filter> sorted = new List<Filter>();
            for(var i=0;i<unsorted.Count;i++){
                List<Join> joins = filterSet.joins.Where(x=>x.filters.IndexOf(unsorted[i].id)!=-1).ToList();
                List<Join> nested = this.sortJoins(joins);
                List<int> joinpath = nested.Select(x=>x.id).ToList();
                unsorted[i].joinpath=joinpath;
                unsorted[i].joinpathlength=joinpath.Count;
                unsorted[i].joinpathstr=string.Join("-",joinpath.Select(x=>x+"").ToList());
                unsorted[i].groupstrprefix="";
                unsorted[i].groupstrsuffix="";
                sorted.Add(unsorted[i]);
            }

            sorted.Sort((a,b)=>{
                return string.Compare(b.joinpathstr,a.joinpathstr);
            });

            int groupLength=0;
            string prevPath="";
            for( int i=0; i<sorted.Count; i++){
                if(prevPath==sorted[i].joinpathstr){
                    groupLength++;
                    if(i==(sorted.Count-1) && groupLength>1){
                        sorted[i-(groupLength-1)].groupstrprefix="(";
                        sorted[i].groupstrsuffix=")";
                    }
                }
                else{
                    if(groupLength>1){
                        sorted[i-(groupLength)].groupstrprefix="(";
                        sorted[i-1].groupstrsuffix=")";
                    }
                    groupLength=1;
                }
                prevPath=sorted[i].joinpathstr;
            }
            
            List<string> sqlList = new List<string>();
            int lastDepth = 0;
            for(var i=0; i<sorted.Count;i++){
                Filter filter = sorted[i];
                Join topJoin  = filterSet.joins.Where(join=>join.id==filter.joinpath[filter.joinpath.Count-1]).Single();
                int currentDepth = findNestDepth(filterSet.joins,topJoin);
                string prefix = currentDepth>lastDepth ? new String('(',currentDepth-lastDepth) : "";
                string suffix = currentDepth<lastDepth ? new String(')',lastDepth-currentDepth) :  "";
                string conjunction = i != 0 ? topJoin.@operator : "";
                if( i>0 && ((currentDepth-lastDepth)==0) && sorted[i-1].groupstrsuffix==")"){
                    conjunction = conjunction == "OR" ? "AND" : "OR";
                }
                conjunction = this.getConjunction(conjunction);
                conjunction = conjunction != "" ? conjunction + "\n" : "";
                sqlList.Add(suffix + " " + conjunction + " " + prefix + filter.groupstrprefix + BuildMetaQuery(filter) +" "+filter.groupstrsuffix);
                lastDepth=currentDepth;
            };
            sqlList[sqlList.Count-1] += new String(')',lastDepth);
            return string.Join("",sqlList);
        }
        public string BuildMetaQuery(Filter filter){
            string op= filter.@operator;
            string relationalstr = "";
            if(filter.EventID>0 || filter.CategoryID>0){
                string relationalprefix = "";
                List<string> relationalsuffix = new List<string>();
                relationalprefix = " JOIN [EventDataSet] eds ON edv.EventDataSetID=eds.EventDataSetID AND ";
                if(filter.EventID>0){
                    relationalsuffix.Add("eds.EventID="+filter.EventID);
                }
                if(filter.CategoryID>0){
                    relationalsuffix.Add("eds.CategoryID="+filter.CategoryID);
                }
                relationalstr=relationalprefix+string.Join(" AND ",relationalsuffix);
            }
            if(filter.key=="EventDataSetID"){
                return " SELECT CAST(@Value"+filter.id+" as int) EventDataSetID";
            }
            if(op=="="){
                return " SELECT edv.EventDataSetID FROM [EventDataValue] edv"+relationalstr+" WHERE [FieldID]=@FieldID"+filter.id+" AND [Value] = @Value"+filter.id;
            }
            else if(op=="!="){
                return " SELECT edv.EventDataSetID FROM [EventDataValue] edv"+relationalstr+" WHERE [FieldID]=@FieldID"+filter.id+" AND [Value] != @Value"+filter.id;
            }
            else if(op=="<>"){
                return " SELECT edv.EventDataSetID FROM [EventDataValue] edv"+relationalstr+" WHERE [FieldID]=@FieldID"+filter.id+" AND [Value] != @Value"+filter.id;
            }
            else if(op=="like"){
                return " SELECT edv.EventDataSetID FROM [EventDataValue] edv"+relationalstr+" WHERE [FieldID]=@FieldID"+filter.id+" AND [Value] LIKE '%'+@Value"+filter.id+"+'%'";
            }
            else if(op=="not like"){
                return " SELECT edv.EventDataSetID FROM [EventDataValue] edv"+relationalstr+" WHERE [FieldID]=@FieldID"+filter.id+" AND [Value] NOT LIKE '%'+@Value"+filter.id+"+'%'";
            }
            else if(op=="in"){
                return " SELECT edv.EventDataSetID FROM [EventDataValue] edv"+relationalstr+" WHERE [FieldID]=@FieldID"+filter.id+" AND [Value] IN @Value"+filter.id;
            }
            else if(op=="not in"){
                return " SELECT edv.EventDataSetID FROM [EventDataValue] edv"+relationalstr+" WHERE [FieldID]=@FieldID"+filter.id+" AND [Value] NOT IN @Value"+filter.id;
            }
            else{
                return " SELECT edv.EventDataSetID FROM [EventDataValue] edv"+relationalstr+" WHERE [FieldID]=@FieldID"+filter.id+" AND [Value]=@Value"+filter.id;
            }
        }
        public string getOperator(string @operator){
            return @operator;
        }
        public string getConjunction(string @operator){
            return @operator == "" ? "" : @operator == "OR" ? " UNION " : " INTERSECT ";
        }

        public List<Join> sortJoins(List<Join> joins){
            List<Join> affiliations = joins;
            List<Join> nestedAffiliations = new List<Join>();
            for(int i=0; i<affiliations.Count; i++){
                bool exists=false;
                for(int x=0; x<nestedAffiliations.Count;x++){
                    if(affiliations[i].id == nestedAffiliations[x].id){
                        exists=true;
                    }
                }
                if(!exists){
                    nestedAffiliations.Add(affiliations[i]);
                    dynamic proxyParent = joins.Where(x=>x.parent==affiliations[i].id).DefaultIfEmpty(null).Single();
                    int previousAffId = affiliations[i].id;
                    while(proxyParent!=null){
                        dynamic actualParent = joins.Where(x=>x.parent==previousAffId).DefaultIfEmpty(null).Single();
                        exists=false;
                        for(int x=0; x<nestedAffiliations.Count;x++){
                            if(actualParent == null || actualParent.id == nestedAffiliations[x].id){
                                exists=true;
                            }
                        }
                        if(exists){
                            proxyParent=null;
                        }
                        else{
                            proxyParent = joins.Where(x=>x.parent==previousAffId).DefaultIfEmpty(null).Single();
                            previousAffId = actualParent.id;
                            nestedAffiliations.Prepend((Join)actualParent);  
                        }
                    }
                }
            }
            return nestedAffiliations;
        }
        public int findNestDepth(List<Join> joinSet ,Join currentJoin){
            if(currentJoin.parent==-1){
                return 0;
            }
            else{
                return findNestDepth(joinSet,joinSet.Where(join=>{
                    return join.id==currentJoin.parent;
                }).Single()) + 1;
            }
        }
        public Event GetEvent(int EventID,IDbTransaction transaction){
            string sql = @"
                SELECT * FROM [Event] WHERE [EventID]=@EventID
            ";
            return this.mDb.Query<Event>(sql,new { EventID=EventID },transaction:transaction).First();
        }
        public dynamic GetEventDataSet(int EventDataSetID, IDbTransaction transaction){
            string sql = @"
                SELECT * FROM [EventDataSet] WHERE [EventDataSetID]=@EventDataSetID
            ";
            return this.mDb.Query<dynamic>(sql,new { EventDataSetID=EventDataSetID },transaction:transaction).First();
        }
        public PivotList GetEventDataSetByID(int EventDataSetID, IDbTransaction transaction){
            string sql=@"
                SELECT 
                eds.[EventDataSetID],
                eds.[EventID],
                eds.[CategoryID],
                cat.[Label] CategoryLabel,
                fc.[FieldID],
                fc.[Label] FieldLabel,
                edv.[Value]
                FROM [EventDataSet] eds
                    JOIN [EventDataValue] edv ON eds.[EventDataSetID]=edv.[EventDataSetID]
                        JOIN [FieldCatalog] fc ON edv.[FieldID]=fc.[FieldID]
                            JOIN [Category] cat ON eds.[CategoryID]=cat.[CategoryID]
                WHERE eds.[EventDataSetID]=@EventDataSetID AND eds.[IsActive]=(1) AND edv.[IsActive]=(1)
            ";
            List<EventDataSetView> vResults = this.mDb.Query<EventDataSetView>(sql,new {
                EventDataSetID=EventDataSetID
            },transaction).ToList();
            PivotList EventDataPivot = new PivotList(vResults);
            return EventDataPivot.ConstructHorizontal();
        }
        public PivotList GetEventDataSet(Event currentCase,Category currentCategory){
            string sql=@"
                SELECT 
                eds.[EventDataSetID],
                eds.[EventID],
                eds.[CategoryID],
                cat.[Label] CategoryLabel,
                fc.[FieldID],
                fc.[Label] FieldLabel,
                edv.[Value]
                FROM [EventDataSet] eds
                    JOIN [EventDataValue] edv ON eds.[EventDataSetID]=edv.[EventDataSetID]
                        JOIN [FieldCatalog] fc ON edv.[FieldID]=fc.[FieldID]
                            JOIN [Category] cat ON eds.[CategoryID]=cat.[CategoryID]
                WHERE eds.[EventID]=@EventID AND eds.[CategoryID]=@CategoryID AND eds.[IsActive]=(1) AND edv.[IsActive]=(1)
            ";
            List<EventDataSetView> vResults = this.mDb.Query<EventDataSetView>(sql,new {
                EventID=currentCase.EventID,
                CategoryID=currentCategory.CategoryID
            }).ToList();
            PivotList EventDataPivot = new PivotList(vResults);
            return EventDataPivot.ConstructHorizontal();
        }

        public EventDataSetView GetEventDataValue(EventDataSetView aValue, IDbTransaction transaction){
            string sql = @"
                SELECT * FROM [EventDataValue] WHERE [EventDataSetID]=@EventDataSetID AND [FieldID]=@FieldID
            ";
            return this.mDb.Query<EventDataSetView>(sql,aValue,transaction:transaction).First();
        }

        public int MarkEventDataValuesInactive(Event anEvent,IDbTransaction transaction){
            string sql = @"
                UPDATE [EventDataValue]
                    SET [IsActive]=(0)
                WHERE [EventDataSetID] IN (
                    SELECT EventDataSetID FROM [EventDataSet] WHERE [EventID]=@EventID
                )
            ";
            return this.mDb.Execute(sql,new {EventID=anEvent.EventID},transaction:transaction);
        }
        public int MarkEventDataSetsInactive(Event anEvent,IDbTransaction transaction){
            string sql = @"
                UPDATE [EventDataSet]
                    SET [IsActive]=(0)
                WHERE [EventID]=@EventID
            ";
            return this.mDb.Execute(sql,new {EventID=anEvent.EventID},transaction:transaction);
        }
        public int MarkEventInactive(Event anEvent,IDbTransaction transaction){
            string sql = @"
                UPDATE [Event]
                    SET [IsActive]=(0)
                WHERE [EventID]=@EventID
            ";
            return this.mDb.Execute(sql,new {EventID=anEvent.EventID},transaction:transaction);
        }

        public int UpsertEvent(Event anEvent,IDbTransaction transaction){
            string prev = @"
                SELECT * FROM [Event] WHERE [EventID]=@EventID
            ";
            dynamic results = this.mDb.Query(prev,anEvent,transaction).ToList();
            dynamic old= new {};
            int surrogate= -1;
            if(results.Count==1){
                old=results[0];
                surrogate=results[0].EventID;
            }
            this.Audit("Event","UPSERT",surrogate,old,anEvent,transaction);

            string sql = @"
                SET IDENTITY_INSERT [Event] ON
                IF EXISTS( SELECT * FROM [Event] WITH (UPDLOCK) WHERE [EventID]=@EventID )
                    UPDATE [Event]
                        SET [IsActive]=@IsActive,
                            [Type]=@Type,
                            [Prefix]=@Prefix
                    WHERE
                        [EventID]=@EventID
                ELSE
                    INSERT INTO [Event] (EventID,Prefix,Type,IsActive)
                    VALUES (@EventID,@Prefix,@Type,@IsActive)
                SET IDENTITY_INSERT [Event] OFF
            ";
            return this.mDb.Execute(sql,anEvent,transaction:transaction);
        }
        public int UpsertEventDataSet(int EventDataSetID,bool IsActive,IDbTransaction transaction){ 
            string prev = @"
                SELECT * FROM [EventDataSet] WHERE [EventDataSetID]=@EventDataSetID
            ";
            dynamic results = this.mDb.Query(prev,new {
                EventDataSetID=EventDataSetID
            },transaction).ToList();
            dynamic old= new {};
            int surrogate= -1;
            if(results.Count==1){
                old=results[0];
                surrogate=results[0].EventDataSetID;
            }
            this.Audit("EventDataSet","UPSERT",surrogate,old,new { EventDataSetID=EventDataSetID, IsActive=IsActive } ,transaction);
            
            string sql = @"
                SET IDENTITY_INSERT [EventDataSet] ON
                IF EXISTS( SELECT * FROM [EventDataSet] WITH (UPDLOCK) WHERE [EventDataSetID]=@EventDataSetID )
                    UPDATE [EventDataSet]
                        SET [IsActive]=@IsActive
                    WHERE [EventDataSetID]=@EventDataSetID
                ELSE
                    INSERT INTO [EventDataSet] ([EventDataSetID],[IsActive],[CreatedDate])
                    VALUES (@EventDataSetID,@IsActive,GETDATE())
                SET IDENTITY_INSERT [EventDataSet] OFF
            ";
            return this.mDb.Execute(sql,new {
                EventDataSetID=EventDataSetID,
                IsActive=IsActive
            },transaction:transaction);
        }
        public int UpsertEventDataValue(EventDataSetView aValue,IDbTransaction transaction){
            string prev = @"
                SELECT * FROM [EventDataValue] WHERE [EventDataSetID]=@EventDataSetID AND [FieldID]=@FieldID
            ";
            dynamic results = this.mDb.Query(prev,new {
                EventDataSetID=aValue.EventDataSetID,
                FieldID=aValue.FieldID
            },transaction).ToList();
            dynamic old= new {};
            int surrogate= -1;
            if(results.Count==1){
                old=results[0];
                surrogate=results[0].EventDataValueID;
            }
            this.Audit("EventDataValue","UPSERT",surrogate,old,aValue,transaction);

            string sql = @"
                IF EXISTS( SELECT * FROM [EventDataValue] WITH (UPDLOCK) WHERE [EventDataSetID]=@EventDataSetID AND [FieldID]=@FieldID )
                    UPDATE [EventDataValue]
                        SET [Value]=@Value,
                            [IsActive]=@IsActive
                    WHERE [EventDataSetID]=@EventDataSetID AND [FieldID]=@FieldID
                ELSE
                    INSERT INTO [EventDataValue] ([EventDataSetID],[FieldID],[IsActive],[Value])
                    VALUES (@EventDataSetID,@FieldID,@IsActive,@Value)
            ";
            return this.mDb.Execute(sql,aValue,transaction:transaction);
        }
    
        public int AddEvent(Event anEvent,IDbTransaction transaction){
            string sql = @"
                INSERT INTO [Event] ([Prefix],[Type],[CreatedDate],[CreatedBy],[IsActive])
                VALUES (@Prefix,@Type,@IsActive);
                SELECT CAST(SCOPE_IDENTITY() as int);
            ";
            int surrogate = this.mDb.Query<int>(sql,anEvent,transaction:transaction).Single();
            this.Audit("Event","INSERT",surrogate,new {},anEvent,transaction);
            return surrogate;
        }
        public int AddEventDataSet(Event anEvent,Category aCategory,IDbTransaction transaction=null){
            string sql = @"
                INSERT INTO [EventDataSet] ([EventID],[CategoryID],[CreatedDate],[IsActive])
                VALUES (@EventID,@CategoryID,GETDATE(),(1));
                SELECT CAST(SCOPE_IDENTITY() as int);
            ";
            int surrogate = this.mDb.Query<int>(sql,new {
                EventID=anEvent.EventID,
                CategoryID=aCategory.CategoryID
            },transaction:transaction).Single();
            this.Audit("EventDataSet","INSERT",surrogate,new {},new {EventDataSetID=surrogate,EventID=anEvent.EventID,CategoryID=aCategory.CategoryID,IsActive=true},transaction);
            return surrogate;
        }
        public int AddEventDataValue(EventDataSetView aValue,IDbTransaction transaction){
            string sql = @"
                INSERT INTO [EventDataValue] ([EventDataSetID],[FieldID],[IsActive],[Value])
                VALUES (@EventDataSetID,@FieldID,(1),@Value);
                SELECT CAST(SCOPE_IDENTITY() as int);
            ";
            int surrogate = this.mDb.Query<int>(sql,new {
                EventDataSetID=aValue.EventDataSetID,
                FieldID=aValue.FieldID,
                Value=aValue.Value,
            },transaction:transaction).Single();
            this.Audit("EventDataValue","INSERT",surrogate,new {},aValue,transaction);
            return surrogate;
        }
        public int AddInstanceRelation(InstanceRelationView aRelation,IDbTransaction transaction){
            string sql = @"
                INSERT INTO [InstanceRelation] (Type,CreatedDate,IsActive)
                VALUES (@Type,GETDATE(),(1));
                SELECT CAST(SCOPE_IDENTITY() as int);
            ";
            int surrogate = this.mDb.Query<int>(sql,aRelation,transaction:transaction).DefaultIfEmpty(-1).Single();
            this.Audit("InstanceRelationKey","INSERT",surrogate,new {},aRelation,transaction);
            return surrogate;
        }
        public int AddInstanceRelationKey(InstanceRelationKey aRelationKey,IDbTransaction transaction){
            string sql = @"
                INSERT INTO [InstanceRelationKey] (InstanceRelationID,ParentTable,ChildTable,ParentPKCol,ChildPKCol,ParentPKID,ChildPKID)
                VALUES (@InstanceRelationID,@ParentTable,@ChildTable,@ParentPKCol,@ChildPKCol,@ParentPKID,@ChildPKID);
                SELECT CAST(SCOPE_IDENTITY() as int);
            ";
            int surrogate = this.mDb.Query<int>(sql,aRelationKey,transaction:transaction).DefaultIfEmpty(-1).Single();
            aRelationKey.InstanceRelationKeyID=surrogate;
            this.Audit("InstanceRelationKey","INSERT",surrogate,new {},aRelationKey,transaction);
            return surrogate;
        }

        public int DeleteEvent(Event anEvent,IDbTransaction transaction){
            Event prev = GetEvent(anEvent.EventID,transaction);
            anEvent.IsActive=false;
            this.Audit("Event","DELETE",anEvent.EventID,prev,anEvent,transaction);
            string sql = @"
                UPDATE [Event]
                    SET [IsActive]=(0)
                WHERE [EventID]=@EventID
            ";
            return this.mDb.Execute(sql,anEvent,transaction:transaction);
        }
        public int DeleteEventDataSet(int EventDataSetID, IDbTransaction transaction){
            dynamic prev = GetEventDataSet(EventDataSetID,transaction);
            this.Audit("EventDataSet","DELETE",EventDataSetID,prev,new{EventDataSetID=EventDataSetID,EventID=prev.EventID,CategoryID=prev.CategoryID,IsActive=false},transaction);
            string sql = @"
                UPDATE [EventDataSet]
                    SET [IsActive]=(0)
                WHERE [EventDataSetID]=@EventDataSetID
            ";
            return this.mDb.Execute(sql,new {EventDataSetID=EventDataSetID},transaction:transaction);
        }
        public int DeleteEventDataValue(EventDataSetView aValue, IDbTransaction transaction){
            EventDataSetView prev = GetEventDataValue(aValue,transaction);
            aValue.EventDataValueID=prev.EventDataValueID;
            this.Audit("EventDataValue","DELETE",prev.EventDataValueID,prev,aValue,transaction);
            string sql = @"
                UPDATE [EventDataValue]
                    SET [IsActive]=(0)
                WHERE [EventDataSetID]=@EventDataSetID AND [FieldID]=@FieldID
            ";
            return this.mDb.Execute(sql,aValue,transaction:transaction);
        }
    
        public int Audit(string tableName, string EventType, int PKID,dynamic oldData, dynamic newData,IDbTransaction transaction){
            string sql = @"
                INSERT INTO [Audit] (TableName,EventType,PKID,Old,New,CreatedDate,CreatedBy)
                VALUES (@tableName,@EventType,@PKID,@oldData,@newData,GETDATE(),@userId)
            ";
            return this.mDb.Execute(sql,new{
                tableName=tableName,
                EventType=EventType,
                PKID=PKID,
                oldData=JsonConvert.SerializeObject(oldData),
                newData=JsonConvert.SerializeObject(newData),
                userId=this.user.UserID
            },transaction:transaction);
        }

        public FileUpload GetFileUpload(int FileID){
            string sql= @"
                SELECT * FROM [File] WHERE [FileID] = @FileID
            ";
            return this.mDb.Query<FileUpload>(sql,new{FileID=FileID}).Single();
        }

        public FileUpload LoadFileBase64(FileUpload currentFile){
            string sql = @"
                SELECT * FROM [File] WHERE [FileID]=@FileID;
            ";

            currentFile = this.mDb.Query<FileUpload>(sql,currentFile).Single();
            FileStream stream = new FileStream(currentFile.Path, FileMode.Open, FileAccess.Read);
            currentFile.Base64 = Extensions.ConvertToBase64(stream);
            return currentFile;
        }
        public FileStream LoadFileStream(FileUpload currentFile){
           string sql = @"
                SELECT * FROM [File] WHERE [FileID]=@FileID;
            ";
            currentFile = this.mDb.Query<FileUpload>(sql,currentFile).Single();
            return new FileStream(currentFile.Path, FileMode.Open, FileAccess.Read);
        }

        public int StoreFile(FileUpload currentFile){
            int surrogate=-1;
            
            var docArray = new string[] { //FILE SIGNATURES
                "D0-CF-11-E0-A1-B1-1A-E1",  //DOC
                "0D-44-4F-43",              //DOC
                "CF-11-E0-A1-B1-1A-E1-00",  //DOC
                "DB-A5-2D-00",              //DOC
                "50-4B-03-04",              //DOCX
                "50-4B-03-04-14-00-06-00",  //DOCX
                "50-4B-03-04",              //XLSX
                "50-4B-03-04-14-00-06-00",  //XLSX
                "D0-CF-11-E0-A1-B1-1A-E1",  //XLS
                "09-08-10-00-00-06-05-00",  //XLS
                "FD-FF-FF-FF-10",           //XLS
                "FD-FF-FF-FF-1F",           //XLS
                "FD-FF-FF-FF-22",           //XLS
                "FD-FF-FF-FF-23",           //XLS
                "FD-FF-FF-FF-28",           //XLS
                "FD-FF-FF-FF-29",           //XLS
                "4D-53-43-46",              //CAB,ONEPKG,PPZ,SNP
                "A0-46-1D-F0",              //PPT
                "25-50-44-46",              //PDF
                "FF-D8-FF-E0",              //JPG
                "FF-D8-FF-E1",              //JPG
                "FF-D8-FF-E8",              //JPG
                "FF-D8-FF-E2",              //JPEG
                "FF-D8-FF-E3",              //JPEG
                "89-50-4E-47-0D-0A-1A-0A",  //PNG
                "47-49-46-38",              //GIF
                "42-4D",                    //BMP
                "49-44-33",                 //MP3
                "FF-Ex",                    //MPEG,MPG,MP3
                "FF-Fx",                    //MPEG,MPG,MP3
                "FF-F1",                    //AAC
                "FF-F9",                    //AAC
                "6D-6F-6F-76",              //MOV
                "66-72-65-65",              //MOV
                "66-74-79-70-71-74-20-20",  //MOV
                "6D-64-61-74",              //MOV
                "77-69-64-65",              //MOV
                "70-6E-6F-74",              //MOV
                "73-6B-69-70",              //MOV
                "66-74-79-70-4D-53-4E-56",  //MP4
                "66-74-79-70-69-73-6F-6D",  //MP4
                "66-74-79-70-6D-70-34-32",  //M4V
                "66-74-79-70-4D-34-56-20",  //M4V/FLV
                "30-26-B2-75-8E-66-CF-11",  //WMV
                "A6-D9-00-AA-00-62-CE-6C",  //WMV
                "52-49-46-46",              //AVI
                "41-56-49-20",              //AVI
                "1A-45-DF-A3-93-42-82-88",  //MKV
                "52-49-46-46",              //WAV
                "57-41-56-45",              //WAV
                "66-4C-61-43-00-00-00-22",  //FLAC
                "66-74-79-70-4D-34-41-20"   //M4A
            };

            var extensionArray = new string[]
            {   //EXTENSIONS 
                "doc","docx","xls","xlsx","pdf","jpg","jpeg","png","gif","mov","mp4","m4v","flv","wmv","avi","wav","ppt","pps","mkv"
            };


            int urlEncodedPrefixPos =currentFile.Base64.IndexOf("; base64,");
            int length = 9;
            if (urlEncodedPrefixPos == -1)
            {
                urlEncodedPrefixPos =currentFile.Base64.IndexOf(";base64,");
                length = 8;
            }
            
            string cbase64 =currentFile.Base64.Substring(urlEncodedPrefixPos == -1 ? 0 : urlEncodedPrefixPos+length);
            
            //Validate Document types as PDF and Word only
            byte[] bytes = Convert.FromBase64String(cbase64);
            string hex = BitConverter.ToString(bytes);

            //Check File Signature Valid
            var valid = false;
            for(var i=0; i<docArray.Length; i++)
            {
                if (hex.IndexOf(docArray[i]) > -1)
                {
                    //contained
                    valid = true;
                    i = docArray.Length;
                }
            }

            //Check Extension Valid
            var extValid = false;
            for(var i=0; i<extensionArray.Length; i++)
            {
                if (currentFile.Extension.ToLower() == "."+extensionArray[i].ToLower())
                {
                    extValid = true;
                    i = extensionArray.Length;
                }
            }
            if (valid == true && extValid == true )
            {
                DirectoryInfo di = Directory.CreateDirectory(Startup.Settings["DocUploadPath"] + @"\" + currentFile.Path + @"\");
                currentFile.Path = Startup.Settings["DocUploadPath"] + @"\" +currentFile.Path + @"\" + "File-" + String.Format("{0:s}", DateTime.Now).Replace(':','_')  +currentFile.Extension;
                //Convert and store Base64 on server after document type validation
                File.WriteAllBytes(currentFile.Path, bytes);

                string sql = @"
                    INSERT INTO [File] ([EventID],[EventDataSetID],[FieldID],[Path],[Label],[Extension],[CreatedDate],[IsActive]) 
                    VALUES (@EventID,@EventDataSetID,@FieldID,@Path, @Label,@Extension, GETDATE(), 1);
                    SELECT CAST(SCOPE_IDENTITY() as int)
                ";
                surrogate = this.mDb.Query<int>(sql,currentFile).Single();
                currentFile.Base64=null;
                currentFile.FileID=surrogate;
                this.Audit("File","INSERT",currentFile.FileID,new {},currentFile,null);
            }

            return surrogate;
        }
    
        public string ReplaceKeyValues(string input, List<dynamic> keyvalues)
        {
            
            for(var i=0; i < keyvalues.Count; i++)
            {
                StringBuilder newString = new StringBuilder();
                int currentIndex = 0;
                int nextIndex = 0;
                int outerIndex = 0;
                while ( currentIndex > -1)
                {
                    outerIndex = currentIndex;
                    currentIndex = input.IndexOf("{{{", currentIndex);
                    if(currentIndex > -1)
                    {
                        newString.Append(input.Substring(outerIndex, currentIndex - outerIndex));
                        nextIndex = input.IndexOf("}}}", currentIndex);
                        if (nextIndex > -1)
                        {
                            string replacementkey = input.Substring(currentIndex + 3, nextIndex - (currentIndex + 3));
                            if (keyvalues[i].ContainsKey(replacementkey))
                            {
                                
                                if (keyvalues[i][replacementkey] != null && keyvalues[i][replacementkey] is string && !(keyvalues[i].ContainsKey("InjectionAllowed") && keyvalues[i]["InjectionAllowed"] == true))
                                {
                                    newString.Append(((string)keyvalues[i][replacementkey].ToString()).Replace("{{{", "(((").Replace("}}}", ")))"));
                                }
                                else if(keyvalues[i][replacementkey] != null)
                                {
                                    newString.Append(ReplaceKeyValues((string)keyvalues[i][replacementkey].ToString(), keyvalues));
                                }
                            }
                            else
                            {
                                newString.Append("{{{" + replacementkey + "}}}");
                            }
                            currentIndex = nextIndex + 3;
                        }
                        else
                        {
                            newString.Append(input.Substring(currentIndex, input.Length - currentIndex));
                            currentIndex = -1;
                        }
                    }
                    else
                    {
                        newString.Append(input.Substring(outerIndex, input.Length - outerIndex));
                        currentIndex = -1;
                    }
                }
                input = newString.ToString();
            }
            return input;
        }
    }
    public static class ObjectExtensions
    {
        public static T ToObject<T>(this IDictionary<string, object> source) where T : class, new()
        {
                var someObject = new T();
                var someObjectType = someObject.GetType();

                foreach (var item in source)
                {
                    someObjectType
                            .GetProperty(item.Key)
                            .SetValue(someObject, item.Value, null);
                }

                return someObject;
        }
        public static Dictionary<string, dynamic> AsDictionary(this object source, BindingFlags bindingAttr = BindingFlags.DeclaredOnly | BindingFlags.Public | BindingFlags.Instance)
        {
            return source.GetType().GetProperties(bindingAttr).ToDictionary
            (
                propInfo => propInfo.Name,
                propInfo => propInfo.GetValue(source, null)
            );

        }
    }

    public static class Extensions
    {
        public static string ConvertToBase64(this Stream stream)
        {
            byte[] bytes;
            using (var memoryStream = new MemoryStream())
            {
                stream.CopyTo(memoryStream);
                bytes = memoryStream.ToArray();
            }

            return Convert.ToBase64String(bytes);
        }
        
    }
}