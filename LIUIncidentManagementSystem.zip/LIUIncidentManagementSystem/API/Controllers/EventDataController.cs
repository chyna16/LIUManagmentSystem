﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using LIU.IMS.API.API;
using LIU.IMS.API.DAL;
using LIU.IMS.API.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;


namespace LIU.IMS.API.Controllers{
    [ApiController]
    [Authorize]
    public class EventDataController : BaseController {
        private readonly EventDataRepository mRepository;
        public EventDataController(ILogger<EventDataController> logger,IUser user) :base(logger,user) {
            mRepository = new EventDataRepository(this.user);
        }

        [HttpGet]
        [Route("/case/{EventID}/category/{categoryStr}")]
        public ResultDTO GetCaseCategoryData(int EventID, string categoryStr){
            User user = (User)HttpContext.Items["metadata"];
            
            Event currentEvent = new Event(){ EventID=EventID };
            Category currentCategory  = mRepository.GetCategory(categoryStr);
            
            List<Dictionary<string,dynamic>> caseDataRows = mRepository.GetEventDataSets(currentEvent,currentCategory).horizontal;
            return new ResultDTO {
                status="ok",
                message="retrieved case data for category within event",
                result=caseDataRows
            };
        }

        [HttpPost]
        [Route("/case/{EventID}/category/{categoryStr}")]
        public ResultDTO AddCaseCategoryData(int EventID, string categoryStr,[FromBody] List<Dictionary<string,dynamic>> payload){
            
            Event currentEvent = new Event(){ EventID=EventID };
            Category currentCategory  = mRepository.GetCategory(categoryStr);

            PivotList caseData = mRepository.AddEventDataSets(currentEvent,currentCategory,payload);
            
            if(caseData.FieldErrors.Count>0 || caseData.TransactionErrors.Count>0){
                return new ResultDTO {
                    status="ok",
                    message="failed to add case data for category within event",
                    result=new {
                        fieldErrors=caseData.FieldErrors,
                        transactionErrors=caseData.TransactionErrors
                    }
                };
            }
            
            return new ResultDTO {
                status="ok",
                message="added case data for category within event",
                result=new {
                    state=caseData.horizontal,
                    detail=caseData.vGroups
                        .Where(vGroupMapping=>vGroupMapping.vGroupMissing.Count>0)
                        .Select(vGroupMapping=>{ return new {PKID=vGroupMapping.vGroupFinalSurrogateID,missing=vGroupMapping.vGroupMissing}; })
                        .ToList()
                }
            };
        }

        [HttpPut]
        [Route("/case/{EventID}/category/{categoryStr}")]
        public ResultDTO UpdateCaseCategoryData(int EventID, string categoryStr,[FromBody] List<Dictionary<string,dynamic>> payload){
            
            Event currentEvent = new Event(){ EventID=EventID };
            Category currentCategory  = mRepository.GetCategory(categoryStr);
            PivotList caseData = mRepository.UpdateEventDataSets(currentEvent,currentCategory,payload);
            
            if(caseData.FieldErrors.Count>0 || caseData.TransactionErrors.Count>0){
                return new ResultDTO {
                    status="ok",
                    message="failed to update case data for category within event",
                    result=new {
                        fieldErrors=caseData.FieldErrors,
                        transactionErrors=caseData.TransactionErrors
                    }
                };
            }
            
            return new ResultDTO {
                status="ok",
                message="updated case data for category within event",
                result=new {
                    state=caseData.horizontal,
                    detail=caseData.vGroups
                        .Where(vGroupMapping=>vGroupMapping.vGroupMissing.Count>0)
                        .Select(vGroupMapping=>{ return new {PKID=vGroupMapping.vGroupFinalSurrogateID,missing=vGroupMapping.vGroupMissing}; })
                        .ToList()
                }
            };
        }

        [HttpDelete]
        [Route("/case/{EventID}/category/{categoryStr}")]
        public ResultDTO DeleteCaseCategoryData(int EventID, string categoryStr,[FromBody] List<Dictionary<string,dynamic>> payload){
            
            Event currentEvent = new Event(){ EventID=EventID };
            Category currentCategory  = mRepository.GetCategory(categoryStr);
            PivotList caseData = mRepository.DeleteEventDataSets(currentEvent,currentCategory,payload);
            
            if(caseData.FieldErrors.Count>0 || caseData.TransactionErrors.Count>0){
                return new ResultDTO {
                    status="ok",
                    message="failed to delete case data for category within event",
                    result=new {
                        fieldErrors=caseData.FieldErrors,
                        transactionErrors=caseData.TransactionErrors
                    }
                };
            }
            
            return new ResultDTO {
                status="ok",
                message="deleted case data for category within event",
                result=new {
                    state=caseData.horizontal
                }
            };
        }
    
        [HttpPost]
        [Route("/case/{EventID}/copy/{EventDataSetID}")]
        public ResultDTO CopyCaseCategoryData(int EventID,int EventDataSetID){
            Event currentEvent = mRepository.GetEvent(EventID,null);
            PivotList caseData = mRepository.CopyEventDataSet(currentEvent,EventDataSetID);
            if(caseData.FieldErrors.Count>0 || caseData.TransactionErrors.Count>0){
                return new ResultDTO {
                    status="ok",
                    message="failed to copy case data for category within event",
                    result=new {
                        fieldErrors=caseData.FieldErrors,
                        transactionErrors=caseData.TransactionErrors
                    }
                };
            }
            return new ResultDTO {
                status="ok",
                message="copied case data for category within event",
                result=new {
                    state=caseData.horizontal
                }
            };
        }

        [HttpGet]
        [Route("/history/past/{EventDataSetID}")]
        public ResultDTO GetPastHistory(int EventDataSetID){
            PivotList caseData = mRepository.GetPastLinkedEventDataSet(EventDataSetID);
            if(caseData.FieldErrors.Count>0 || caseData.TransactionErrors.Count>0){
                return new ResultDTO {
                    status="ok",
                    message="failed to retrieve past history for data set",
                    result=new {
                        fieldErrors=caseData.FieldErrors,
                        transactionErrors=caseData.TransactionErrors
                    }
                };
            }
            return new ResultDTO {
                status="ok",
                message="retrieved past history for data set",
                result=new {
                    state=caseData.horizontal
                }
            };
        }

        [HttpGet]
        [Route("/history/future/{EventDataSetID}")]
        public ResultDTO GetFutureHistory(int EventDataSetID){
            PivotList caseData = mRepository.GetFutureLinkedEventDataSet(EventDataSetID);
            if(caseData.FieldErrors.Count>0 || caseData.TransactionErrors.Count>0){
                return new ResultDTO {
                    status="ok",
                    message="failed to retrieve future history for data set",
                    result=new {
                        fieldErrors=caseData.FieldErrors,
                        transactionErrors=caseData.TransactionErrors
                    }
                };
            }
            return new ResultDTO {
                status="ok",
                message="retrieved future history for data set",
                result=new {
                    state=caseData.horizontal
                }
            };
        }

        [HttpGet]
        [Route("/history/all/{EventDataSetID}")]
        public ResultDTO GetAllHistory(int EventDataSetID){
            PivotList caseData = mRepository.GetAllLinkedEventDataSet(EventDataSetID);
            if(caseData.FieldErrors.Count>0 || caseData.TransactionErrors.Count>0){
                return new ResultDTO {
                    status="ok",
                    message="failed to retrieve all history for data set",
                    result=new {
                        fieldErrors=caseData.FieldErrors,
                        transactionErrors=caseData.TransactionErrors
                    }
                };
            }
            return new ResultDTO {
                status="ok",
                message="retrieved all history for data set",
                result=new {
                    state=caseData.horizontal
                }
            };
        }
    }
}
