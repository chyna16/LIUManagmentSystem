﻿using LIU.IMS.API.API;
using LIU.IMS.API.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;


namespace LIU.IMS.API.Controllers{
    [ApiController]
    [Authorize]
    public class BaseController : ControllerBase {
        
        public readonly ILogger<dynamic> logger;
        public readonly User user;

        public BaseController(ILogger<dynamic> logger,IUser user) {
            this.logger=logger;
            this.user=(User)user;
        }
    }
}
