﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using LIU.IMS.API.DAL;
using LIU.IMS.API.API;
using LIU.IMS.API.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;


namespace LIU.IMS.API.Controllers{
    [ApiController]
    [Authorize]
    public class SearchController : BaseController {
        private readonly BaseRepository mRepository;
        public SearchController(ILogger<UserController> logger,IUser user) :base(logger,user) {
            mRepository = new BaseRepository(this.user);
        }

        [HttpGet]
        [Route("/search/")]
        public ResultDTO GetSearchResults(string q=null,string c=null,string key=null){
            int caseNum;
            if(Int32.TryParse(q, out  caseNum)){
                // Search for individual cases and return
                List<Event> results = mRepository.SearchEvent(caseNum);
                return new ResultDTO() {
                    status="ok",
                    message="Searched for CaseID within Events",
                    result=results
                };
            }
            else{
                if(key == null){
                    //Search for Pivoted EventDataSetValue on firstname and lastname by default
                    Dictionary<string,Dictionary<string,dynamic>> results = mRepository.SearchEventDataSet(q,c);
                    return new ResultDTO() {
                        status="ok",
                        message="Searched for FirstName,LastName within EventDataSets",
                        result=results
                    };
                }
                else{
                    Dictionary<string,Dictionary<string,dynamic>> results = mRepository.SearchEventDataSetDynamic(q,key);
                    return new ResultDTO() {
                        status="ok",
                        message="Searched for FirstName,LastName within EventDataSets",
                        result=results
                    };
                }
            }
        }
        
        [HttpPost]
        [Route("/search/")]
        public ResultDTO GetSearchResultsAdvanced([FromBody] FilterSet filterSet){
            return new ResultDTO(){
                status="ok",
                message="Searched against "+string.Join(",",filterSet.filters.Select(filter=>filter.key))+" within EventDataSets",
                result=mRepository.SearchEventDataSetAdvanced(filterSet)
            };
        }
    
        [HttpPost]
        [Route("/search/select/")]
        public ResultDTO GetRelationalFieldSearchResults([FromBody] SearchSelect relationalSearch){
            string searchMessageStr = "performed relational search on:"+
                                        " EventID="+relationalSearch.EventID+
                                        ", CategoryLabel="+relationalSearch.CategoryLabel+
                                        ", FieldLabel="+relationalSearch.FieldLabel+
                                        ", SearchValue="+relationalSearch.SearchValue;
            Event searchedEvent = new Event() { EventID=relationalSearch.EventID };
            Category searchedCategory = mRepository.GetCategory(relationalSearch.CategoryLabel);
            Field searchedField = mRepository.GetField(relationalSearch.FieldLabel);
            List<CategoryField> selectCategoryFields = mRepository.GetSearchSelectCategoryFields(searchedCategory,searchedField);
            FilterSet advancedFilters = new FilterSet(){
                filters=new List<Filter>(),
                joins= new List<Join>()
            };
            advancedFilters.joins.Add(new Join(){
                id=1,
                parent=-1,
                filters=new List<int>(),
                @operator="OR"
            });
            int index=1;
            selectCategoryFields.ForEach((CategoryField)=>{
                advancedFilters.joins[0].filters.Add(index);
                advancedFilters.filters.Add(new Filter(){
                    id = index,
                    key = CategoryField.FieldLabel,
                    @operator = "LIKE",
                    value = relationalSearch.SearchValue
                });
                index++;
            });
            Dictionary<string,Dictionary<string,dynamic>> results = mRepository.SearchEventDataSetAdvanced(advancedFilters);
            selectCategoryFields.ForEach((CategoryField)=>{
                
                if(results.ContainsKey(CategoryField.CategoryLabel)){
                    List<Selection> selections = new List<Selection>();
            
                    ((List<Dictionary<string,dynamic>>)results[CategoryField.CategoryLabel]["records"]).ForEach((row)=>{
                        string replacement = CategoryField.SelectLabel;
                        selections.Add(new Selection(){
                            value=row["EventDataSetID"],
                            label=replacement == null ? row["EventDataSetID"] : mRepository.ReplaceKeyValues(replacement,new List<dynamic>(){row})
                        });
                    });
                    results[CategoryField.CategoryLabel]["records"]= selections;
                }
            });

            return new ResultDTO(){
                status="ok",
                message=searchMessageStr,
                result=results
            };
        }
    }
}
