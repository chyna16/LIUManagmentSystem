using System;
using System.Net; 
using System.Net.Http;
using System.Net.Http.Headers;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using LIU.IMS.API.DAL;
using LIU.IMS.API.API;
using LIU.IMS.API.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using System.IO;


namespace LIU.IMS.API.Controllers{
    [ApiController]
    [Authorize]
    public class FileController : BaseController {
        private readonly FileRepository mRepository;
        public FileController(ILogger<FileController> logger,IUser user) : base(logger,user){
            mRepository = new FileRepository(this.user);
        }

        [Route("file/download/metadata/{fileID}")]
        [HttpGet]
        public ResultDTO GetFileMetaData(int fileID){
            FileUpload requestedFile = mRepository.GetFileUpload(fileID);
            return new ResultDTO {
                status="ok",
                message="Retrieved File MetaData",
                result=requestedFile
            };
        }

        [Route("file/download/base64/{fileID}")]
        [HttpGet]
        public ResultDTO DownloadFileJSON(int fileID){
            FileUpload requestedFile = new FileUpload(){FileID=fileID};
            requestedFile = mRepository.GetFile(requestedFile);
            if(requestedFile.Base64==null){
                return new ResultDTO {
                    status = "ok",
                    message = "Failed to download file",
                    result = requestedFile
                };
            }
            return new ResultDTO {
                status = "ok",
                message = "File downloaded successfully",
                result = requestedFile
            };
        }

        [Route("file/download/stream/{fileID}")]
        [HttpGet]
        public IActionResult DownloadFilePhysical(int fileID){
            FileUpload requestedFile = mRepository.GetFileUpload(fileID);
            FileStream stream = mRepository.GetFileStream(requestedFile);
            string contentType = mRepository.GetFileType(requestedFile.Path);
            return new FileStreamResult(stream,contentType);
        }

        

        [Route("file/upload/")]
        [HttpPost]
        public ResultDTO UploadFileCase([FromBody] FileUpload currentFile)
        {
            currentFile = mRepository.AddFile(currentFile);
            if(currentFile.FileID==-1){
               return new ResultDTO
                {
                    status = "ok",
                    message = "Failed to upload file",
                    result = currentFile
                }; 
            }
            return new ResultDTO
            {
                status = "ok",
                message = "File uploaded successfully",
                result = currentFile
            };
        }
    }
    
}