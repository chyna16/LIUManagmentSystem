﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using LIU.IMS.API.API;
using LIU.IMS.API.Models;
using LIU.IMS.API.DAL;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;


namespace LIU.IMS.API.Controllers{
    [ApiController]
    [Authorize]
    public class EventController : BaseController {
        public readonly EventRepository mRepository;
        public EventController(ILogger<EventController> logger,IUser user) : base(logger,user) {
            mRepository = new EventRepository(this.user);
        }

        [HttpGet]
        [Route("/cases")]
        public ResultDTO GetCases() {
            return new ResultDTO{
                status = "ok",
                message = "cases returned",
                result = mRepository.GetEvents()
            };
        }

        [HttpGet]
        [Route("/case/{eventId}")]
        public ResultDTO GetCase(int eventId) {
            User user = (User)HttpContext.Items["metadata"];
            Event currentEvent= mRepository.GetEventRestore(eventId);
            return new ResultDTO{
                status = "ok",
                message = currentEvent == null ? "no cases found" : "case restoration point returned",
                result = currentEvent
            };
        }

        [HttpPut]
        [Route("/case")]
        public ResultDTO UpdateCase(int eventId,[FromBody] Event eventInfo) {
            Event final = mRepository.UpdateEvent(eventInfo);
            
            if(final.TransactionErrors.Count>0 || final.FieldErrors.Count>0){
                return new ResultDTO{
                    status="ok",
                    message="failed to update case",
                    result = final
                };
            }
            return new ResultDTO{
                status = "ok",
                message = "case updated",
                result = eventInfo
            };
        }
        
        [HttpDelete]
        [Route("/case/{eventId}")]
        public ResultDTO DeleteCase(int eventId) {
            Event final = mRepository.DeleteEvent(new Event(){EventID=eventId});
            
            if(final.TransactionErrors.Count>0 || final.FieldErrors.Count>0){
                return new ResultDTO{
                    status = "ok",
                    message = "failed to remove case",
                    result = final 
                };
            }
            return new ResultDTO{
                status = "ok",
                message = "case removed",
                result = final 
            };
        }

        [HttpPost]
        [Route("/case")]
        public ResultDTO AddCase([FromBody] Event eventInfo) {
            Event final =  mRepository.AddEvent(eventInfo);
            
            if(final.TransactionErrors.Count>0 || final.FieldErrors.Count>0){
                return new ResultDTO{
                    status = "ok",
                    message = "failed to add case",
                    result = eventInfo
                };
            }
            return new ResultDTO{
                status = "ok",
                message = "case added",
                result = eventInfo
            };
        }

        [HttpPost]
        [Route("/case/restore")]
        public ResultDTO RestoreCase([FromBody] Event eventInfoRestore){
            Event finalRestoration = mRepository.RestoreEvent(eventInfoRestore);
            if(finalRestoration.TransactionErrors.Count>0 || finalRestoration.FieldErrors.Count>0){
                return new ResultDTO{
                    status="ok",
                    message="failed to restore case",
                    result=finalRestoration
                };
            }
            return new ResultDTO {
                status = "ok",
                message = "restored case",
                result = finalRestoration
            };
        }
        /*
DATA RESTORE BODY EXAMPLE:
{
    "EventID": 1,
    "Name": null,
    "Categories": {
        "Person": {
            "CategoryID": 2,
            "CategoryLabel": "Person",
            "FieldCategories": null,
            "Records": [
                {
                    "EventDataSetID": 1,
                    "FirstName": "Ryan",
                    "LastName": "Montgomery",
                    "Gender": "Male"
                },
                {
                    "EventDataSetID": 2,
                    "FirstName": "John",
                    "LastName": "Doe",
                    "Gender": "Male"
                },
                {
                    "EventDataSetID": 5,
                    "FirstName": "Justin",
                    "LastName": "Fusco",
                    "Gender": "Male"
                },
                {
                    "EventDataSetID": 6,
                    "FirstName": "Justin",
                    "LastName": "Lau",
                    "Gender": "Male"
                },
                {
                    "EventDataSetID": 7,
                    "FirstName": "Chyna",
                    "LastName": "Browne",
                    "Gender": "Female"
                }
            ],
            "Fields": [
                {
                    "CategoryID": 2,
                    "CategoryLabel": "Person",
                    "FieldID": 1,
                    "FieldLabel": "FirstName",
                    "FieldDescription": "First name",
                    "FieldDataType": "String",
                    "FieldSelector": null
                },
                {
                    "CategoryID": 2,
                    "CategoryLabel": "Person",
                    "FieldID": 2,
                    "FieldLabel": "LastName",
                    "FieldDescription": "Last name",
                    "FieldDataType": "String",
                    "FieldSelector": null
                },
                {
                    "CategoryID": 2,
                    "CategoryLabel": "Person",
                    "FieldID": 3,
                    "FieldLabel": "DOB",
                    "FieldDescription": "Date of Birth",
                    "FieldDataType": "Date",
                    "FieldSelector": null
                },
                {
                    "CategoryID": 2,
                    "CategoryLabel": "Person",
                    "FieldID": 4,
                    "FieldLabel": "Email",
                    "FieldDescription": "Email",
                    "FieldDataType": "String",
                    "FieldSelector": null
                },
                {
                    "CategoryID": 2,
                    "CategoryLabel": "Person",
                    "FieldID": 5,
                    "FieldLabel": "Phone",
                    "FieldDescription": "Phone",
                    "FieldDataType": "String",
                    "FieldSelector": null
                },
                {
                    "CategoryID": 2,
                    "CategoryLabel": "Person",
                    "FieldID": 6,
                    "FieldLabel": "Country",
                    "FieldDescription": "Country",
                    "FieldDataType": "String",
                    "FieldSelector": null
                },
                {
                    "CategoryID": 2,
                    "CategoryLabel": "Person",
                    "FieldID": 7,
                    "FieldLabel": "State",
                    "FieldDescription": "State",
                    "FieldDataType": "String",
                    "FieldSelector": null
                },
                {
                    "CategoryID": 2,
                    "CategoryLabel": "Person",
                    "FieldID": 8,
                    "FieldLabel": "City",
                    "FieldDescription": "City",
                    "FieldDataType": "String",
                    "FieldSelector": null
                },
                {
                    "CategoryID": 2,
                    "CategoryLabel": "Person",
                    "FieldID": 9,
                    "FieldLabel": "Address",
                    "FieldDescription": "Street",
                    "FieldDataType": "String",
                    "FieldSelector": null
                },
                {
                    "CategoryID": 2,
                    "CategoryLabel": "Person",
                    "FieldID": 10,
                    "FieldLabel": "Gender",
                    "FieldDescription": "Gender",
                    "FieldDataType": "String",
                    "FieldSelector": null
                },
                {
                    "CategoryID": 2,
                    "CategoryLabel": "Person",
                    "FieldID": 11,
                    "FieldLabel": "Weight",
                    "FieldDescription": "Weight (lb)",
                    "FieldDataType": "Number",
                    "FieldSelector": null
                },
                {
                    "CategoryID": 2,
                    "CategoryLabel": "Person",
                    "FieldID": 12,
                    "FieldLabel": "Height",
                    "FieldDescription": "Height (e.g. 5'5\")",
                    "FieldDataType": "String",
                    "FieldSelector": null
                },
                {
                    "CategoryID": 2,
                    "CategoryLabel": "Person",
                    "FieldID": 13,
                    "FieldLabel": "License",
                    "FieldDescription": "Image of License",
                    "FieldDataType": "File",
                    "FieldSelector": null
                }
            ]
        }
    },
    "IsActive": true
}
        */
    }
}
