﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using LIU.IMS.API.DAL;
using LIU.IMS.API.API;
using LIU.IMS.API.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;


namespace LIU.IMS.API.Controllers{
    [ApiController]
    [Authorize]
    public class LookupController : BaseController {
        private readonly BaseRepository mRepository;
        public LookupController(ILogger<UserController> logger,IUser user) :base(logger,user) {
            mRepository = new BaseRepository(this.user);
        }

        [HttpGet]
        [Route("category/{categoryStr}")]
        public ResultDTO GetCategoryFields(string categoryStr){
            List<CategoryField> fields = mRepository.GetCategoryFields(mRepository.GetCategory(categoryStr));
            return new ResultDTO {
                status="ok",
                message="Returned active fields in category",
                result=fields
            };
        }
        
        [HttpGet]
        [Route("categories")]
        public ResultDTO GetCategories(){
            List<Category> fields = mRepository.GetCategories();
            fields.ForEach((category)=>{
                category.FieldCategories= mRepository.GetCategoryFields(category);
            });
            return new ResultDTO {
                status="ok",
                message="Returned active categories defined",
                result=fields
            };
        }
    }
}
