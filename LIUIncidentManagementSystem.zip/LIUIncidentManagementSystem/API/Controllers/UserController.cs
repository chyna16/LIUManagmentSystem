﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using LIU.IMS.API.API;
using LIU.IMS.API.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;


namespace LIU.IMS.API.Controllers{
    [ApiController]
    [Authorize]
    public class UserController : BaseController {
        public UserController(ILogger<UserController> logger,IUser user) : base(logger,user) {}

        [HttpGet]
        [Route("users")]
        public ResultDTO Get() {
            // TODO : Call UserRepository and connect DB
            //_logger.LogError("UsersRoute Here",null);
            
            return new ResultDTO{
                status = "ok",
                message = "users returned",
                result = new User[]{
                    new User{
                        UserID = 1
                    },
                    new User{
                        UserID = 1
                    }
                }
            };
        }
    }
}
